// ============================================================
// Category D — Services (10 templates)
// ============================================================

function D1_PerfMarketing({ w, h }) {
  const isSquare = w === h;
  return (
    <>
      <GridBg />
      <TopLeftLogo top={40} left={40} height={22} />
      <div style={{ position: 'absolute', top: 40, right: 40 }}><Pill tone="coralFill" size="sm">Performance</Pill></div>

      <div style={{
        position: 'absolute', inset: isSquare ? '120px 50px 60px' : '90px 50px 50px',
        display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 30,
      }}>
        <div style={{ display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
          <Display size={isSquare ? 90 : 62} color={C.white} lh={0.9}>Meta + Google<br/>+ Programmatic.</Display>
          <Body size={isSquare ? 15 : 13} color={C.bodySoft} style={{ marginTop: 16 }}>
            Campaign structure, creative testing cadence, AI bidding, full attribution.
          </Body>
          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginTop: 18 }}>
            {['ROAS', 'Creative Testing', 'AI Bidding'].map(t => <Pill key={t} tone="neutral" size="sm">{t}</Pill>)}
          </div>
          <div style={{ marginTop: 22 }}>
            <Pill tone="coral" size="lg">$30M+ Managed</Pill>
          </div>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column' }}>
          <svg viewBox="0 0 260 180" style={{ width: '100%', height: isSquare ? 200 : 150 }}>
            {[[10,140,30,30],[50,110,30,60],[90,85,30,85],[130,60,30,110],[170,35,30,135],[210,12,30,158]].map(([x,y,bw,bh],i)=>(
              <rect key={i} x={x} y={y} width={bw} height={bh} fill={C.coral} opacity={0.3+i*0.12} rx="2"/>
            ))}
          </svg>
          <PhotoPlaceholder h={isSquare ? 180 : 140} label="Drop ad creative screenshot" style={{ marginTop: 14 }} />
        </div>
      </div>
    </>
  );
}

function D2_EmailRetention({ w, h }) {
  const isSquare = w === h;
  return (
    <>
      <GridBg />
      <TopLeftLogo top={40} left={40} height={22} />
      <div style={{
        position: 'absolute', inset: isSquare ? '100px 50px 50px' : '80px 50px 40px',
        display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 30,
      }}>
        <div>
          <svg width="56" height="56" viewBox="0 0 48 48" fill="none">
            <rect x="4" y="10" width="40" height="28" rx="3" stroke={C.coral} strokeWidth="2.5"/>
            <path d="M4 12l20 14 20-14" stroke={C.coral} strokeWidth="2.5" fill="none"/>
          </svg>
          <Display size={isSquare ? 80 : 58} color={C.white} lh={0.9} style={{ marginTop: 18 }}>
            Klaviyo flows<br/>that print revenue.
          </Display>
          <Body size={isSquare ? 15 : 13} color={C.bodySoft} style={{ marginTop: 14 }}>
            35–45% of revenue should come from email. Does yours?
          </Body>
          <div style={{ marginTop: 20, display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
            {['Welcome', 'Cart', 'Win-Back', 'VIP'].map(t=>(
              <div key={t} style={{
                padding: '10px 14px', background: C.navyLight, border: `1px solid ${C.border}`,
                borderLeft: `3px solid ${C.coral}`, borderRadius: 6,
                fontFamily: F.body, fontSize: 13, fontWeight: 700, color: C.white,
              }}>{t}</div>
            ))}
          </div>
        </div>
        <PhotoPlaceholder h="100%" label="Drop email creative" />
      </div>
    </>
  );
}

function D3_PeshwaService({ w, h }) {
  const isSquare = w === h;
  return (
    <>
      <GridBg />
      <CoralGlow size={600} top="50%" left="50%" op={0.3} />
      <TopLeftLogo top={40} left={40} height={22} />

      <svg viewBox="0 0 600 400" style={{ position: 'absolute', left: '50%', top: '38%', transform: 'translate(-50%,-50%)', width: isSquare ? 600 : 500, height: isSquare ? 400 : 280 }}>
        {Array.from({length:9}).map((_,i)=>{
          const a = (i/9)*Math.PI*2 - Math.PI/2;
          const x = 300 + Math.cos(a)*160, y = 200 + Math.sin(a)*130;
          return <g key={i}>
            <line x1="300" y1="200" x2={x} y2={y} stroke={C.coral} strokeWidth="1" opacity="0.3"/>
            <circle cx={x} cy={y} r="26" fill={C.navyLight} stroke={C.coral} strokeWidth="1.5"/>
          </g>;
        })}
        <circle cx="300" cy="200" r="50" fill={C.coral}/>
        <text x="300" y="208" textAnchor="middle" fill="#fff" style={{fontFamily:F.display,fontSize:24}}>CMD</text>
      </svg>

      <div style={{ position: 'absolute', left: 0, right: 0, bottom: isSquare ? 80 : 40, textAlign: 'center', padding: '0 60px' }}>
        <Display size={isSquare ? 100 : 62} color={C.white} lh={0.9}>Peshwa Swarm · 9 AI Agents.</Display>
        <Body size={isSquare ? 15 : 13} color={C.bodySoft} style={{ marginTop: 10 }}>
          Replacing entire departments. Running 24/7.
        </Body>
      </div>
    </>
  );
}

function D4_WebApp({ w, h }) {
  const isSquare = w === h;
  return (
    <>
      <GridBg />
      <TopLeftLogo top={40} left={40} height={22} />

      {/* browser mockup */}
      <div style={{
        position: 'absolute', top: isSquare ? 100 : 80, left: 50, right: 50,
        height: isSquare ? 380 : 260,
        background: C.navyLight, borderRadius: 10, border: `1px solid ${C.border}`,
        overflow: 'hidden', display: 'flex', flexDirection: 'column',
      }}>
        <div style={{ display: 'flex', gap: 6, padding: '12px 16px', borderBottom: `1px solid ${C.border}` }}>
          <div style={{ width: 10, height: 10, borderRadius: '50%', background: 'rgba(255,255,255,0.15)' }}/>
          <div style={{ width: 10, height: 10, borderRadius: '50%', background: 'rgba(255,255,255,0.15)' }}/>
          <div style={{ width: 10, height: 10, borderRadius: '50%', background: C.coral }}/>
          <div style={{ marginLeft: 20, fontFamily: 'monospace', fontSize: 11, color: C.muted }}>sorted.agency/build</div>
        </div>
        <div style={{ flex: 1, padding: 24, fontFamily: 'monospace', fontSize: 13, color: C.bodySoft, lineHeight: 1.7 }}>
          <div><span style={{ color: C.coral }}>const</span> stack = [</div>
          <div style={{ paddingLeft: 24 }}>'Next.js', 'Shopify', 'React Native', 'SaaS',</div>
          <div>];</div>
          <div style={{ marginTop: 12 }}><span style={{ color: C.coral }}>// kickoff → live</span></div>
          <div>deploy(<span style={{ color: '#9DC8FF' }}>'72 hours'</span>);</div>
        </div>
      </div>

      <div style={{ position: 'absolute', left: 50, right: 50, bottom: 40 }}>
        <Display size={isSquare ? 90 : 60} color={C.white} lh={0.9}>From idea to live · 72 hours.</Display>
        <Body size={isSquare ? 14 : 12} color={C.bodySoft} style={{ marginTop: 8 }}>
          We built FactoryOS, Spark and more. Next.js · Shopify · React Native · SaaS.
        </Body>
      </div>
    </>
  );
}

function D5_BrandCreative({ w, h }) {
  return (
    <>
      <GridBg />
      <TopLeftLogo top={40} left={40} height={22} />
      <div style={{
        position: 'absolute', inset: '100px 50px 50px',
        display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 30,
      }}>
        <div>
          <Display size={96} color={C.white} lh={0.9}>We build brands that move culture.</Display>
          <div style={{ display: 'flex', gap: 0, marginTop: 30, height: 90, borderRadius: 10, overflow: 'hidden' }}>
            {[C.navy, C.coral, C.white, C.muted, C.navyLight].map((c,i)=>(
              <div key={i} style={{ flex: 1, background: c }}/>
            ))}
          </div>
          <div style={{ marginTop: 20 }}>
            <AvatarPlaceholder size={90} label="Brand mark area" />
          </div>
        </div>
        <PhotoPlaceholder h="100%" label="Drop brand collateral" />
      </div>
    </>
  );
}

function D6_Strategy({ w, h }) {
  const steps = ['Audit', 'Strategy', 'Deploy', 'Scale'];
  return (
    <>
      <GridBg />
      <TopLeftLogo top={40} left={40} height={22} />
      <div style={{ position: 'absolute', top: 80, left: 50, right: 50 }}>
        <Display size={72} color={C.white} lh={0.9}>90-day growth roadmap.</Display>
      </div>

      <svg viewBox="0 0 1100 200" style={{ position: 'absolute', left: 50, right: 50, top: 220, width: 'calc(100% - 100px)' }}>
        <path d="M 20 160 Q 200 140, 350 110 T 700 60 T 1080 20" stroke={C.coral} strokeWidth="3" fill="none"/>
        {[20, 370, 720, 1080].map((x,i)=>{
          const y = [160, 110, 60, 20][i];
          return <g key={i}>
            <circle cx={x} cy={y} r="8" fill={C.coral}/>
            <circle cx={x} cy={y} r="14" fill="none" stroke={C.coral} opacity="0.3"/>
          </g>;
        })}
      </svg>

      <div style={{ position: 'absolute', left: 50, right: 50, bottom: 50, display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 12 }}>
        {steps.map((s,i)=>(
          <div key={i} style={{ background: C.navyLight, border: `1px solid ${C.border}`, borderTop: `2px solid ${C.coral}`, borderRadius: 8, padding: '14px 16px' }}>
            <Eyebrow color={C.coral} size={11}>{String(i+1).padStart(2,'0')}</Eyebrow>
            <div style={{ fontFamily: F.display, fontSize: 28, color: C.white, marginTop: 4 }}>{s}</div>
          </div>
        ))}
      </div>
    </>
  );
}

function D7_ServicesGrid({ w, h }) {
  const services = [
    ['Ads', 'M0 16l8-12 6 8 4-4 6 8H0z'],
    ['Email', 'M2 4h20v16H2zM2 4l10 8 10-8'],
    ['AI', 'M12 2l3 7 7 1-5 5 1 7-6-3-6 3 1-7-5-5 7-1z'],
    ['Web', 'M4 4h16v16H4zM4 8h16M8 4v16'],
    ['Brand', 'M12 3L3 9l9 6 9-6zM3 14l9 6 9-6'],
    ['Strategy', 'M3 18l6-6 4 4 8-10'],
  ];
  return (
    <>
      <GridBg />
      <div style={{ position: 'absolute', top: 50, left: 50, right: 50, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <Display size={60} color={C.white}>One partner. Full stack.</Display>
        <Logo height={22} />
      </div>

      <div style={{ position: 'absolute', left: 50, right: 50, top: 170, bottom: 50, display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gridTemplateRows: 'repeat(2,1fr)', gap: 16 }}>
        {services.map(([label, path], i)=>(
          <div key={i} style={{ background: C.navyLight, border: `1px solid ${C.border}`, borderRadius: 12, padding: 24, display: 'flex', flexDirection: 'column', gap: 14 }}>
            <div style={{ width: 56, height: 56, borderRadius: 12, background: 'rgba(232,38,75,0.12)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke={C.coral} strokeWidth="2">
                <path d={path}/>
              </svg>
            </div>
            <div style={{ fontFamily: F.display, fontSize: 28, color: C.white, letterSpacing: '0.5px' }}>{label}</div>
          </div>
        ))}
      </div>
    </>
  );
}

function D8_WhiteLabel({ w, h }) {
  return (
    <>
      <GridBg />
      <TopLeftLogo top={40} left={40} height={22} />
      <div style={{ position: 'absolute', top: 40, right: 40 }}><Pill tone="neutral" size="sm">For Agencies</Pill></div>

      <div style={{ position: 'absolute', inset: '100px 50px 60px', display: 'grid', gridTemplateColumns: '1fr 1.2fr', gap: 40, alignItems: 'center' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 20 }}>
          <AvatarPlaceholder size={120} label="Your agency logo" />
          <div style={{ fontFamily: F.display, fontSize: 48, color: C.muted }}>+</div>
          <Mark size={96} />
        </div>
        <div>
          <Display size={64} color={C.white} lh={0.9}>Your brand. Our execution.</Display>
          <div style={{ marginTop: 20, display: 'flex', flexDirection: 'column', gap: 8 }}>
            {['Performance Marketing', 'Klaviyo Flows', 'Creative Production', 'Peshwa Reporting', 'Dev + SaaS Build'].map(s=>(
              <div key={s} style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                <span style={{ color: C.coral }}>✓</span>
                <Body size={14} color={C.white}>{s}</Body>
              </div>
            ))}
          </div>
          <Body size={12} color={C.muted} style={{ marginTop: 20 }}>Full NDA · USD billing · US timezone.</Body>
        </div>
      </div>
    </>
  );
}

function D9_EmailFlows({ w, h }) {
  const flows = [
    ['Welcome Series',     'First touch'],
    ['Abandoned Cart',     'Recover 20%+'],
    ['Post-Purchase',      'LTV driver'],
    ['Win-Back',           'Lapsed customers'],
    ['Browse Abandon',     'Intent signal'],
    ['VIP',                'Top 10%'],
    ['Sunset',             'List hygiene'],
  ];
  return (
    <>
      <GridBg />
      <TopLeftLogo top={40} left={40} height={22} />
      <div style={{ position: 'absolute', top: 40, right: 40 }}><Pill tone="coralFill" size="sm">Klaviyo</Pill></div>

      <div style={{ position: 'absolute', top: 110, left: 60, right: 60 }}>
        <Display size={76} color={C.white} lh={0.9}>All 7 flows.<br/>Running on autopilot.</Display>
      </div>

      <div style={{ position: 'absolute', left: 60, right: 60, top: 320, display: 'flex', flexDirection: 'column', gap: 10 }}>
        {flows.map(([t, s], i)=>(
          <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 16, padding: '12px 18px', background: C.navyLight, border: `1px solid ${C.border}`, borderRadius: 8 }}>
            <div style={{ width: 10, height: 10, borderRadius: '50%', background: C.coral }}/>
            <div style={{ fontFamily: F.body, fontSize: 16, fontWeight: 700, color: C.white, flex: 1 }}>{t}</div>
            <Body size={12} color={C.muted}>{s}</Body>
          </div>
        ))}
      </div>
    </>
  );
}

function D10_MetaAds({ w, h }) {
  const isSquare = w === h;
  return (
    <>
      <GridBg />
      <TopLeftLogo top={40} left={40} height={22} />

      <div style={{ position: 'absolute', inset: '100px 50px 50px', display: 'flex', flexDirection: 'column' }}>
        <Display size={isSquare ? 130 : 88} color={C.coral} lh={0.88} ls="-1px">We spend<br/>$30M+ in ads.</Display>
        <Body size={isSquare ? 16 : 13} color={C.bodySoft} style={{ marginTop: 14 }}>
          AI-optimised bidding. Human-led strategy.
        </Body>

        <div style={{ marginTop: 30 }}>
          <Eyebrow size={11} color={C.muted}>ROAS Benchmark</Eyebrow>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginTop: 10 }}>
            <Body size={12} color={C.muted}>Industry avg</Body>
            <div style={{ flex: 1, height: 12, background: C.navyLight, borderRadius: 6, overflow: 'hidden' }}>
              <div style={{ width: '45%', height: '100%', background: C.muted }}/>
            </div>
            <Body size={12} color={C.muted} weight={700}>2.0×</Body>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginTop: 8 }}>
            <Body size={12} color={C.white}>Sorted</Body>
            <div style={{ flex: 1, height: 12, background: C.navyLight, borderRadius: 6, overflow: 'hidden' }}>
              <div style={{ width: '95%', height: '100%', background: C.coral }}/>
            </div>
            <Body size={12} color={C.coral} weight={700}>4.5×</Body>
          </div>
        </div>

        <div style={{ marginTop: 'auto', display: 'flex', gap: 8, flexWrap: 'wrap' }}>
          {['UGC', 'Static', 'Video', 'Carousel', 'Shop Ads', 'Retargeting'].map(t=>(
            <Pill key={t} tone="neutral" size="sm">{t}</Pill>
          ))}
        </div>
      </div>
    </>
  );
}

Object.assign(window, {
  D1_PerfMarketing, D2_EmailRetention, D3_PeshwaService, D4_WebApp, D5_BrandCreative,
  D6_Strategy, D7_ServicesGrid, D8_WhiteLabel, D9_EmailFlows, D10_MetaAds,
});
