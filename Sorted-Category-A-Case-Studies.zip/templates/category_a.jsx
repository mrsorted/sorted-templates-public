// ============================================================
// Category A — Case Studies (12 templates)
// ============================================================

// ---------- A1 · Case Study Full Stats ----------
// IG 1080×1080, TW 1200×675, LI 1200×627
function A1_CaseStudyFullStats({ w, h }) {
  const isSquare = w === h;
  const pad = isSquare ? 60 : 50;
  return (
    <>
      <GridBg />
      <CoralGlow size={600} top="-20%" right="-20%" op={0.28} />

      {/* top chrome */}
      <div style={{
        position: 'absolute', top: pad, left: pad, right: pad,
        display: 'flex', justifyContent: 'space-between', alignItems: 'center',
      }}>
        <Pill tone="coralFill" size="md">Case Study</Pill>
        <Logo height={isSquare ? 26 : 22} />
      </div>

      {/* tag */}
      <div style={{
        position: 'absolute', top: pad + (isSquare ? 78 : 60), left: pad,
      }}>
        <Pill tone="neutral" size="sm">D2C · Email</Pill>
      </div>

      {/* hero stat + image split */}
      <div style={{
        position: 'absolute', left: pad, right: pad,
        top: pad + (isSquare ? 130 : 100),
        bottom: pad + (isSquare ? 200 : 150),
        display: 'grid', gridTemplateColumns: isSquare ? '1fr 300px' : '1fr 260px', gap: 32,
      }}>
        <div style={{ alignSelf: 'center' }}>
          <Display size={isSquare ? 220 : 180} color={C.coral} lh={0.85} ls="-2px">$17.9M</Display>
          <div style={{ marginTop: 14 }}>
            <Eyebrow color={C.white} size={isSquare ? 16 : 13} ls="0.26em">Attributed Email Revenue</Eyebrow>
          </div>
          <Body size={isSquare ? 15 : 13} color={C.muted} style={{ marginTop: 10 }}>
            URC Beverages · 12-month Klaviyo engagement
          </Body>
        </div>
        <PhotoPlaceholder h="100%" label="Drop client creative" />
      </div>

      {/* metric row */}
      <div style={{
        position: 'absolute', left: pad, right: pad,
        bottom: pad + (isSquare ? 110 : 80),
        display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 16,
      }}>
        <StatCard value="28.2%" label="Growth" />
        <StatCard value="44%" label="Revenue Share" />
        <StatCard value="12 Mo" label="Engagement" />
      </div>

      {/* CTA */}
      <div style={{ position: 'absolute', bottom: pad, left: pad }}>
        <CtaButton size={isSquare ? 'md' : 'sm'}>Book Your Free Audit</CtaButton>
      </div>
      <BottomRightMark bottom={pad} right={pad} size={isSquare ? 48 : 40} />
    </>
  );
}

// ---------- A2 · Revenue Hero Stat ----------
function A2_RevenueHero({ w, h }) {
  const isSquare = w === h;
  return (
    <>
      <GridBg />
      <CoralGlow size={900} top="50%" left="50%" op={0.32}
        size_={800} />
      <div style={{
        position: 'absolute', inset: 0,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
      }}>
        <div style={{
          width: 700, height: 700, borderRadius: '50%',
          background: 'radial-gradient(circle, rgba(232,38,75,0.35), transparent 60%)',
          filter: 'blur(60px)', position: 'absolute',
        }} />
      </div>

      {/* corner */}
      <TopRightLogo top={48} right={48} height={26} />
      <div style={{ position: 'absolute', top: 48, left: 48 }}>
        <Eyebrow>Case Study · 2025</Eyebrow>
      </div>

      {/* hero */}
      <div style={{
        position: 'absolute', inset: 0,
        display: 'flex', flexDirection: 'column',
        alignItems: 'center', justifyContent: 'center', gap: 18,
      }}>
        <Display size={isSquare ? 360 : 280} color={C.coral} lh={0.85} ls="-4px">$17.9M</Display>
        <Eyebrow color={C.white} size={isSquare ? 18 : 14} ls="0.32em">Attributed Email Revenue</Eyebrow>
        <Body size={isSquare ? 15 : 13} color={C.muted}>12 months · 1 client · Klaviyo</Body>
      </div>

      <div style={{ position: 'absolute', top: 48, right: 48 + 160 }}>
        <AvatarPlaceholder size={64} label="Client logo" />
      </div>

      <BottomRightMark bottom={40} right={40} size={52} />
      <BottomLeftUrl />
    </>
  );
}

// ---------- A3 · ROAS Win ----------
function A3_ROASWin({ w, h }) {
  const isSquare = w === h;
  return (
    <>
      <GridBg />
      <TopLeftLogo top={48} left={48} height={24} />

      <div style={{
        position: 'absolute', inset: isSquare ? '180px 60px 160px' : '130px 60px 110px',
        display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 40, alignItems: 'center',
      }}>
        <div>
          <Display size={isSquare ? 340 : 260} color={C.coral} lh={0.85} ls="-3px">4.5×</Display>
          <div style={{ marginTop: 4 }}>
            <Eyebrow color={C.white} size={isSquare ? 15 : 12} ls="0.28em">Average ROAS</Eyebrow>
          </div>
        </div>

        {/* bar chart */}
        <div>
          <Body size={isSquare ? 17 : 14} color={C.bodySoft} style={{ marginBottom: 18 }}>
            Across <span style={{ color: C.white, fontWeight: 700 }}>100+ D2C brands</span> we've scaled since 2022.
          </Body>
          <svg viewBox="0 0 260 150" width="100%" height={isSquare ? 180 : 130}>
            {[
              [10, 110, 36, 40], [56, 85, 36, 65], [102, 60, 36, 90],
              [148, 40, 36, 110], [194, 18, 36, 132],
            ].map(([x, y, bw, bh], i) => (
              <g key={i}>
                <rect x={x} y={y} width={bw} height={bh} fill={C.coral} opacity={0.25 + i * 0.18} rx={2} />
              </g>
            ))}
            <line x1="0" y1="150" x2="260" y2="150" stroke={C.border} />
          </svg>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 8 }}>
            <Body size={10} color={C.muted}>Q1</Body>
            <Body size={10} color={C.muted}>Q2</Body>
            <Body size={10} color={C.muted}>Q3</Body>
            <Body size={10} color={C.muted}>Q4</Body>
            <Body size={10} color={C.muted}>Now</Body>
          </div>
        </div>
      </div>

      {/* badge */}
      <div style={{
        position: 'absolute', bottom: 48, left: 60,
      }}>
        <Pill tone="coral" size="lg">$30M+ Ad Spend Managed</Pill>
      </div>
      <BottomRightMark bottom={48} right={48} />
    </>
  );
}

// ---------- A4 · Before / After Split ----------
function A4_BeforeAfter({ w, h }) {
  const isSquare = w === h;
  return (
    <>
      <GridBg opacity={0.5} />

      {/* centre divider */}
      <div style={{
        position: 'absolute', left: '50%', top: 80, bottom: 80,
        width: 1, background: `linear-gradient(to bottom, transparent, ${C.coral}, transparent)`,
        transform: 'translateX(-50%)',
      }} />

      <div style={{
        position: 'absolute', inset: '50px 40px 50px',
        display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 0,
      }}>
        {/* BEFORE */}
        <div style={{ padding: isSquare ? '30px 40px' : '20px 30px' }}>
          <Eyebrow color={C.muted} size={13} ls="0.3em">Before</Eyebrow>
          <Display size={isSquare ? 100 : 72} color={C.muted} lh={0.9} style={{ marginTop: 8 }}>Before</Display>
          <PhotoPlaceholder h={isSquare ? 220 : 160} label="Drop screenshot — before" style={{ marginTop: 20 }} />
          <div style={{ marginTop: 24, display: 'flex', flexDirection: 'column', gap: 14 }}>
            {[
              '2.1× ROAS · flatlining revenue',
              'Klaviyo at 8% of total revenue',
            ].map((t, i) => (
              <div key={i} style={{ display: 'flex', gap: 12, alignItems: 'flex-start' }}>
                <div style={{
                  width: 22, height: 22, borderRadius: '50%',
                  background: 'rgba(255,255,255,0.06)', color: C.muted,
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontSize: 14, fontWeight: 700, flexShrink: 0,
                }}>×</div>
                <Body size={isSquare ? 15 : 13} color={C.muted}>{t}</Body>
              </div>
            ))}
          </div>
        </div>

        {/* AFTER */}
        <div style={{ padding: isSquare ? '30px 40px' : '20px 30px' }}>
          <Eyebrow color={C.coral} size={13} ls="0.3em">After</Eyebrow>
          <Display size={isSquare ? 100 : 72} color={C.coral} lh={0.9} style={{ marginTop: 8 }}>After</Display>
          <PhotoPlaceholder h={isSquare ? 220 : 160} label="Drop screenshot — after" style={{ marginTop: 20 }} />
          <div style={{ marginTop: 24, display: 'flex', flexDirection: 'column', gap: 14 }}>
            {[
              '4.8× ROAS · sustained 9 months',
              'Klaviyo at 44% of total revenue',
            ].map((t, i) => (
              <div key={i} style={{ display: 'flex', gap: 12, alignItems: 'flex-start' }}>
                <div style={{
                  width: 22, height: 22, borderRadius: '50%',
                  background: C.coral, color: '#fff',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontSize: 13, fontWeight: 700, flexShrink: 0,
                }}>✓</div>
                <Body size={isSquare ? 15 : 13} color={C.white}>{t}</Body>
              </div>
            ))}
          </div>
        </div>
      </div>

      <TopLeftLogo top={30} left={40} height={20} />
      <BottomRightMark bottom={24} right={40} size={36} />
    </>
  );
}

// ---------- A5 · Growth % Hero ----------
function A5_GrowthHero({ w, h }) {
  const isSquare = w === h;
  return (
    <>
      <GridBg />
      <CoralGlow size={800} bottom="-30%" left="-20%" op={0.35} />

      <TopRightLogo top={48} right={48} height={26} />
      <Mark size={40} style={{ position: 'absolute', top: 52, right: 160 }} />

      <div style={{
        position: 'absolute', inset: 0,
        display: 'flex', flexDirection: 'column', justifyContent: 'center',
        padding: isSquare ? '0 60px' : '0 80px',
      }}>
        <Display
          size={isSquare ? 540 : 420}
          color={C.coral}
          lh={0.85}
          ls="-6px"
          style={{ textShadow: `0 0 80px rgba(232,38,75,0.3)` }}
        >718%</Display>
        <div style={{ marginTop: 10 }}>
          <Eyebrow color={C.white} size={isSquare ? 20 : 16} ls="0.3em">Revenue Growth · 6 Months</Eyebrow>
        </div>
        <Body size={isSquare ? 16 : 13} color={C.muted} style={{ marginTop: 10 }}>
          Homestead Collective · Meta + Google + Klaviyo
        </Body>
      </div>

      {/* swipe indicator */}
      <div style={{
        position: 'absolute', bottom: 40, right: 48,
        display: 'flex', alignItems: 'center', gap: 10,
      }}>
        <Body size={11} color={C.coral} weight={700}
              style={{ letterSpacing: '0.28em', textTransform: 'uppercase' }}>Swipe to see how</Body>
        <svg width="20" height="10" viewBox="0 0 22 10"><path d="M1 5h20M16 1l5 4-5 4" stroke={C.coral} strokeWidth="1.5" fill="none"/></svg>
      </div>
    </>
  );
}

// ---------- A6 · Shopify Win ----------
function A6_ShopifyWin({ w, h }) {
  const isSquare = w === h;
  return (
    <>
      <GridBg />
      <TopLeftLogo top={40} left={40} height={22} />
      <div style={{ position: 'absolute', top: 40, right: 40 }}>
        <Pill tone="coralFill">Shopify Win</Pill>
      </div>

      {/* top strip photo */}
      <div style={{
        position: 'absolute', top: 100, left: 40, right: 40,
        height: isSquare ? 360 : 240,
      }}>
        <PhotoPlaceholder h="100%" label="Drop Shopify dashboard screenshot" />
      </div>

      {/* main stat */}
      <div style={{
        position: 'absolute', left: 40,
        top: isSquare ? 490 : 360,
      }}>
        <Display size={isSquare ? 180 : 140} color={C.coral} lh={0.9} ls="-2px">$1.45M</Display>
        <div style={{ marginTop: 6 }}>
          <Eyebrow color={C.white} size={isSquare ? 14 : 12}>Shopify Sales · 90 Days</Eyebrow>
        </div>
      </div>

      {/* stats row */}
      <div style={{
        position: 'absolute', left: 40, right: 40,
        bottom: 40,
        display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 14,
      }}>
        <StatCard value="27K" label="Orders" />
        <StatCard value="22.96%" label="Return Rate" />
        <StatCard value="+25%" label="YoY" />
      </div>
    </>
  );
}

// ---------- A7 · With Client Photo ----------
function A7_WithClientPhoto({ w, h }) {
  const isSquare = w === h;
  return (
    <>
      <GridBg />
      <div style={{ position: 'absolute', top: 0, left: 0, right: 0, height: 4, background: C.coral }} />

      <div style={{
        position: 'absolute', inset: isSquare ? '40px 40px 40px 40px' : '40px 40px 40px 40px',
        display: 'grid', gridTemplateColumns: isSquare ? '40% 1fr' : '35% 1fr', gap: 32,
      }}>
        <PhotoPlaceholder h="100%" label="Drop client headshot" />
        <div style={{ display: 'flex', flexDirection: 'column', padding: '20px 0' }}>
          <Eyebrow>Case Study:</Eyebrow>
          <Display size={isSquare ? 80 : 58} color={C.white} lh={0.9} style={{ marginTop: 16 }}>
            3× revenue<br/>in 90 days.
          </Display>
          <Body size={isSquare ? 15 : 13} color={C.bodySoft} style={{ marginTop: 14 }}>
            "Sorted rebuilt our growth engine from the ground up. Every week felt like a year of progress."
          </Body>
          <Body size={isSquare ? 13 : 11} color={C.muted} style={{ marginTop: 8 }}>
            — Avni Mehra · Founder, Leafmark Beauty
          </Body>

          <div style={{
            display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 12,
            marginTop: 'auto',
          }}>
            <StatCard value="3.1×" label="Revenue" />
            <StatCard value="41%" label="Email share" />
            <StatCard value="5.2×" label="ROAS" />
          </div>

          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginTop: 18 }}>
            <Body size={12} color={C.coral} weight={700}
                  style={{ letterSpacing: '0.24em', textTransform: 'uppercase' }}>Read full case →</Body>
            <Logo height={20} />
          </div>
        </div>
      </div>
    </>
  );
}

// ---------- A8 · Screenshot Proof ----------
function A8_ScreenshotProof({ w, h }) {
  const isSquare = w === h;
  const topH = isSquare ? '60%' : '58%';
  return (
    <>
      <GridBg />
      <div style={{
        position: 'absolute', top: 40, left: 40, right: 40, height: `calc(${topH} - 20px)`,
      }}>
        <PhotoPlaceholder h="100%" label="Drop Klaviyo / Shopify / GSC screenshot" />
      </div>

      <div style={{
        position: 'absolute', left: 40, right: 40,
        top: `calc(${topH} + 30px)`, bottom: 30,
        display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 20,
      }}>
        <div>
          <Display size={isSquare ? 110 : 80} color={C.coral} lh={0.9} ls="-1px">+$892K</Display>
          <Body size={isSquare ? 14 : 12} color={C.bodySoft} style={{ marginTop: 6 }}>
            Email revenue, 30 days. Real client dashboard.
          </Body>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
          <Logo height={22} />
          <Mark size={32} />
        </div>
      </div>
    </>
  );
}

// ---------- A9 · Carousel Cover ----------
function A9_CarouselCover({ w, h }) {
  return (
    <>
      <CoralGlow size={900} top="-30%" right="-30%" op={0.4} />
      <CoralGlow size={800} bottom="-30%" left="-20%" op={0.3} />
      <GridBg />

      {/* slide counter */}
      <div style={{
        position: 'absolute', top: 48, left: 48,
      }}>
        <div style={{
          fontFamily: F.display, fontSize: 64, color: C.coral, lineHeight: 1,
        }}>01</div>
        <Body size={11} color={C.muted} weight={700}
              style={{ letterSpacing: '0.28em', textTransform: 'uppercase', marginTop: 4 }}>
          / 05
        </Body>
      </div>

      <TopRightLogo top={52} right={48} height={22} />

      <div style={{
        position: 'absolute', left: 60, right: 60, top: 220,
      }}>
        <Eyebrow size={13} ls="0.3em">Sorted Case Study</Eyebrow>
        <Display size={140} color={C.white} lh={0.88} ls="-2px" style={{ marginTop: 18 }}>
          How we 3×'d<br/>a D2C brand<br/>in 90 days.
        </Display>
      </div>

      {/* swipe */}
      <div style={{
        position: 'absolute', bottom: 48, left: 60,
        display: 'flex', alignItems: 'center', gap: 14,
      }}>
        <Body size={12} color={C.coral} weight={700} style={{ letterSpacing: '0.3em', textTransform: 'uppercase' }}>
          Swipe →
        </Body>
      </div>
      <BottomRightMark bottom={44} right={48} size={48} />
    </>
  );
}

// ---------- A10 · Carousel — The Problem ----------
function A10_CarouselProblem({ w, h }) {
  return (
    <>
      <GridBg />
      <Mark size={360} style={{
        position: 'absolute', bottom: -80, right: -80, opacity: 0.05,
      }} />

      <div style={{ position: 'absolute', top: 48, left: 48 }}>
        <div style={{
          fontFamily: F.display, fontSize: 52, color: C.muted, lineHeight: 1,
        }}>02</div>
        <Body size={11} color={C.muted} weight={700}
              style={{ letterSpacing: '0.28em', textTransform: 'uppercase', marginTop: 4 }}>/ 05</Body>
      </div>

      <TopRightLogo top={52} right={48} height={22} />

      <div style={{ position: 'absolute', left: 60, right: 60, top: 220 }}>
        <Eyebrow color={C.coral} size={13} ls="0.3em">The Problem</Eyebrow>
        <Display size={120} color={C.coral} lh={0.88} style={{ marginTop: 14 }}>
          The problem.
        </Display>

        <div style={{ marginTop: 60, display: 'flex', flexDirection: 'column', gap: 28 }}>
          {[
            { h: '$180K/mo spend, 1.9× ROAS.', s: 'Meta campaigns were bleeding cash on broad audiences with no creative testing cadence.' },
            { h: 'Klaviyo at 7% of revenue.', s: 'Only a Welcome series live. No Browse, no Cart, no Win-Back. Leaving 30%+ of revenue on the table.' },
          ].map((item, i) => (
            <div key={i} style={{ display: 'flex', gap: 18, alignItems: 'flex-start' }}>
              <div style={{
                width: 30, height: 30, borderRadius: '50%',
                background: 'rgba(255,255,255,0.05)', color: C.coral,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontSize: 16, fontWeight: 700, flexShrink: 0,
                border: `1px solid ${C.coral}`,
              }}>✗</div>
              <div>
                <Body size={20} weight={700} color={C.white} lh={1.3}>{item.h}</Body>
                <Body size={14} color={C.muted} style={{ marginTop: 6 }}>{item.s}</Body>
              </div>
            </div>
          ))}
        </div>
      </div>
    </>
  );
}

// ---------- A11 · Carousel — What We Did ----------
function A11_CarouselWhatWeDid({ w, h }) {
  return (
    <>
      <GridBg />

      <div style={{ position: 'absolute', top: 48, left: 48 }}>
        <div style={{ fontFamily: F.display, fontSize: 52, color: C.muted }}>03</div>
        <Body size={11} color={C.muted} weight={700}
              style={{ letterSpacing: '0.28em', textTransform: 'uppercase', marginTop: 4 }}>/ 05</Body>
      </div>
      <TopRightLogo top={52} right={48} height={22} />

      <div style={{ position: 'absolute', left: 60, right: 60, top: 220 }}>
        <Eyebrow size={13} ls="0.3em">What We Did</Eyebrow>
        <Display size={120} color={C.white} lh={0.88} style={{ marginTop: 14 }}>What we did.</Display>

        <div style={{ marginTop: 56, display: 'flex', flexDirection: 'column', gap: 26 }}>
          {[
            ['01', 'Rebuilt Meta account structure.', 'Campaign consolidation, Advantage+, creative testing framework live in 10 days.'],
            ['02', 'Deployed 7 Klaviyo flows.', 'Welcome · Browse · Cart · Post-Purchase · Win-Back · VIP · Sunset — all split-tested.'],
            ['03', 'Peshwa Swarm on reporting.', '9 AI agents pulling daily Shopify + Klaviyo + Meta data into a live founder dashboard.'],
          ].map(([n, h, s], i) => (
            <div key={i} style={{ display: 'flex', gap: 20, alignItems: 'flex-start' }}>
              <div style={{
                width: 52, height: 52, borderRadius: '50%',
                background: C.coral, color: '#fff',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontFamily: F.display, fontSize: 22, letterSpacing: '1px', flexShrink: 0,
              }}>{n}</div>
              <div>
                <Body size={20} weight={700} color={C.white} lh={1.3}>{h}</Body>
                <Body size={14} color={C.bodySoft} style={{ marginTop: 4 }}>{s}</Body>
              </div>
            </div>
          ))}
        </div>
      </div>
    </>
  );
}

// ---------- A12 · Carousel — The Result ----------
function A12_CarouselResult({ w, h }) {
  return (
    <>
      <CoralGlow size={900} top="50%" left="50%" op={0.35} />
      <GridBg />

      <div style={{ position: 'absolute', top: 48, left: 48 }}>
        <div style={{ fontFamily: F.display, fontSize: 52, color: C.coral }}>05</div>
        <Body size={11} color={C.muted} weight={700}
              style={{ letterSpacing: '0.28em', textTransform: 'uppercase', marginTop: 4 }}>/ 05</Body>
      </div>
      <div style={{ position: 'absolute', top: 48, right: 48 }}>
        <AvatarPlaceholder size={56} label="Client logo" />
      </div>

      <div style={{
        position: 'absolute', inset: 0,
        display: 'flex', flexDirection: 'column',
        alignItems: 'center', justifyContent: 'center',
        textAlign: 'center', padding: '0 60px',
      }}>
        <Eyebrow color={C.coral} size={14} ls="0.32em">The Result</Eyebrow>
        <Display size={260} color={C.coral} lh={0.85} ls="-3px" style={{ marginTop: 16 }}>3.1×</Display>
        <Eyebrow color={C.white} size={15} ls="0.3em" style={{ marginTop: 6 }}>Revenue · 90 Days</Eyebrow>
        <Body size={18} color={C.bodySoft} style={{ marginTop: 40, maxWidth: 640 }}>
          Want this for your brand?
        </Body>
        <div style={{ marginTop: 22 }}>
          <CtaButton size="lg">Book a Free Audit</CtaButton>
        </div>
      </div>

      <div style={{ position: 'absolute', bottom: 40, left: 0, right: 0, display: 'flex', justifyContent: 'center' }}>
        <Logo height={22} />
      </div>
    </>
  );
}

Object.assign(window, {
  A1_CaseStudyFullStats, A2_RevenueHero, A3_ROASWin, A4_BeforeAfter,
  A5_GrowthHero, A6_ShopifyWin, A7_WithClientPhoto, A8_ScreenshotProof,
  A9_CarouselCover, A10_CarouselProblem, A11_CarouselWhatWeDid, A12_CarouselResult,
});
