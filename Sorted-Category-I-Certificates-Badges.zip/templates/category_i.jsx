// Category I — Certificates & Badges (6)
function I1_CertSuccess({w,h}){return(<>
<div style={{position:'absolute',inset:30,border:`2px solid ${C.coral}`,borderRadius:8}}/>
<div style={{position:'absolute',inset:42,border:`1px solid ${C.border}`,borderRadius:4}}/>
<GridBg/>
<div style={{position:'absolute',inset:0,display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',padding:'0 80px',textAlign:'center'}}>
<Eyebrow color={C.coral} size={13} ls="0.32em">Certificate of Achievement</Eyebrow>
<div style={{marginTop:30}}><AvatarPlaceholder size={80} label="Client logo"/></div>
<Display size={56} color={C.white} lh={1} style={{marginTop:20}}>This certifies that<br/>[BRAND] achieved<br/>3.1× revenue growth<br/>with Sorted.</Display>
<div style={{marginTop:30,display:'flex',gap:40,alignItems:'center'}}>
<div style={{width:100,borderTop:`1px solid ${C.muted}`,paddingTop:8}}><Body size={11} color={C.muted}>Issued · Jan 2026</Body></div>
<Mark size={56}/>
<div style={{width:100,borderTop:`1px solid ${C.muted}`,paddingTop:8}}><Body size={11} color={C.muted}>Sorted Agency LLC</Body></div>
</div>
</div></>);}

function I2_RoasBadge({w,h}){const{coral,white,navyLight,navy}=C;return(<>
<GridBg/>
<div style={{position:'absolute',inset:0,display:'flex',alignItems:'center',justifyContent:'center'}}>
<svg width="640" height="640" viewBox="0 0 400 400">
<circle cx="200" cy="200" r="190" fill={navyLight}/>
<circle cx="200" cy="200" r="180" fill="none" stroke={coral} strokeWidth="2"/>
<circle cx="200" cy="200" r="155" fill="none" stroke={coral} strokeOpacity="0.4" strokeWidth="1" strokeDasharray="4 6"/>
<circle cx="200" cy="200" r="130" fill={navy}/>
<defs><path id="tp" d="M60,200 a140,140 0 1,1 280,0"/></defs>
<text fontSize="13" fontFamily="DM Sans" fontWeight="700" fill={coral} letterSpacing="4"><textPath href="#tp" startOffset="50%" textAnchor="middle">ACHIEVED WITH SORTED · 2025</textPath></text>
<text x="200" y="190" textAnchor="middle" fill={coral} style={{fontFamily:"Bebas Neue",fontSize:80,letterSpacing:"2px"}}>4.5×</text>
<text x="200" y="230" textAnchor="middle" fill={white} style={{fontFamily:"DM Sans",fontSize:16,fontWeight:700,letterSpacing:"6px"}}>ROAS CLUB</text>
</svg></div>
<TopLeftLogo top={40} left={40} height={22}/>
<div style={{position:'absolute',bottom:40,left:0,right:0,textAlign:'center'}}><Body size={13} color={C.coral} weight={700} style={{letterSpacing:'0.28em',textTransform:'uppercase'}}>Share your badge 🏆</Body></div>
</>);}

function I3_EmailBadge({w,h}){return(<>
<GridBg/>
<div style={{position:'absolute',inset:0,display:'flex',alignItems:'center',justifyContent:'center'}}>
<svg width="640" height="640" viewBox="0 0 400 400">
<circle cx="200" cy="200" r="190" fill={C.navyLight}/>
<circle cx="200" cy="200" r="180" fill="none" stroke={C.coral} strokeWidth="2"/>
<circle cx="200" cy="200" r="150" fill="none" stroke={C.coral} strokeOpacity="0.3" strokeWidth="1" strokeDasharray="3 5"/>
<circle cx="200" cy="200" r="125" fill={C.navy}/>
<g transform="translate(170,170)"><rect width="60" height="40" rx="3" fill="none" stroke={C.coral} strokeWidth="2.5"/><path d="M0 2l30 22 30-22" stroke={C.coral} strokeWidth="2.5" fill="none"/></g>
<defs><path id="et" d="M60,200 a140,140 0 1,1 280,0"/></defs>
<text fontSize="13" fontFamily="DM Sans" fontWeight="700" fill={C.coral} letterSpacing="4"><textPath href="#et" startOffset="50%" textAnchor="middle">40%+ EMAIL REVENUE CLUB · SORTED</textPath></text>
<text x="200" y="250" textAnchor="middle" fill={C.white} style={{fontFamily:"Bebas Neue",fontSize:28}}>2025 MEMBER</text>
</svg></div>
<TopLeftLogo top={40} left={40} height={22}/>
</>);}

function I4_PartnerCert({w,h}){return(<>
<div style={{position:'absolute',inset:30,border:`1px solid ${C.coral}`,borderRadius:6}}/>
<GridBg/>
<div style={{position:'absolute',inset:0,display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',padding:'0 60px',textAlign:'center'}}>
<Eyebrow color={C.coral} size={13} ls="0.32em">Certified</Eyebrow>
<Display size={60} color={C.white} lh={0.95} style={{marginTop:20}}>Sorted Partner Agency.</Display>
<div style={{marginTop:40,display:'flex',gap:40,alignItems:'center'}}>
<AvatarPlaceholder size={100} label="Partner logo"/>
<div style={{fontFamily:F.display,fontSize:60,color:C.muted}}>×</div>
<Mark size={90}/>
</div>
<Body size={13} color={C.muted} style={{marginTop:40}}>Powered by Sorted · Issued 2026 · Verified</Body>
</div></>);}

function I5_Milestone({w,h}){return(<>
<GridBg/><CoralGlow size={700} top="50%" left="50%" op={0.25}/>
<div style={{position:'absolute',inset:0,display:'flex',alignItems:'center',justifyContent:'center'}}>
<svg width="700" height="700" viewBox="0 0 400 400">
{[190,160,130,100,70].map((r,i)=><circle key={i} cx="200" cy="200" r={r} fill="none" stroke={C.coral} strokeWidth="1" strokeOpacity={0.15+i*0.12}/>)}
<circle cx="200" cy="200" r="60" fill={C.coral}/>
<text x="200" y="220" textAnchor="middle" fill="#fff" style={{fontFamily:"Bebas Neue",fontSize:60,letterSpacing:"1px"}}>100+</text>
</svg></div>
<TopLeftLogo top={40} left={40} height={22}/>
<div style={{position:'absolute',bottom:80,left:0,right:0,textAlign:'center'}}>
<Display size={70} color={C.white} lh={0.9}>100+ brands scaled.</Display>
<Body size={14} color={C.muted} style={{marginTop:10}}>And counting.</Body>
</div></>);}

function I6_YearAward({w,h}){return(<>
<div style={{position:'absolute',inset:30,border:`2px solid ${C.coral}`,borderRadius:6}}/>
<GridBg/>
<div style={{position:'absolute',inset:0,display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',padding:'0 70px',textAlign:'center'}}>
<svg width="60" height="60" viewBox="0 0 48 48" fill="none"><path d="M24 32c7-2 12-8 12-16V6H12v10c0 8 5 14 12 16z" stroke={C.coral} strokeWidth="2.5"/></svg>
<Eyebrow color={C.coral} size={13} ls="0.32em" style={{marginTop:20}}>Sorted Awards · 2025</Eyebrow>
<Display size={70} color={C.coral} lh={0.95} style={{marginTop:18}}>D2C Brand<br/>of the Year.</Display>
<div style={{marginTop:30}}><AvatarPlaceholder size={80} label="Winning brand logo"/></div>
<Body size={14} color={C.bodySoft} style={{marginTop:30}}>Presented for outstanding revenue growth and operational excellence.</Body>
<div style={{marginTop:30,width:200,borderTop:`1px solid ${C.muted}`,paddingTop:8}}><Body size={11} color={C.muted}>Dhiraj Palekar · Founder</Body></div>
</div></>);}

Object.assign(window, {I1_CertSuccess, I2_RoasBadge, I3_EmailBadge, I4_PartnerCert, I5_Milestone, I6_YearAward});
