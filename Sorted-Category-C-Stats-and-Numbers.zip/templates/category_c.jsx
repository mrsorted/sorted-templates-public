// ============================================================
// Category C — Stats & Numbers (10 templates)
// ============================================================

// ---------- C1 · 4-Stat Grid ----------
function C1_FourStatGrid({ w, h }) {
  const isSquare = w === h;
  const pad = isSquare ? 56 : 44;
  return (
    <>
      <GridBg />
      <div style={{
        position: 'absolute', top: pad, left: pad, right: pad,
        display: 'flex', justifyContent: 'space-between', alignItems: 'center',
      }}>
        <Eyebrow size={12} ls="0.3em">Sorted · By the Numbers</Eyebrow>
        <Logo height={22} />
      </div>

      <div style={{
        position: 'absolute', left: pad, right: pad,
        top: pad + (isSquare ? 70 : 50), bottom: pad + 50,
        display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gridTemplateRows: 'repeat(2, 1fr)',
        gap: 16,
      }}>
        {[
          ['100+',  'Brands Scaled'],
          ['$40M+', 'Revenue Tracked'],
          ['4.5×',  'Avg ROAS'],
          ['9',     'AI Agents'],
        ].map(([v, l], i) => (
          <div key={i} style={{
            background: C.navyLight, border: `1px solid ${C.border}`,
            borderTop: `3px solid ${C.coral}`, borderRadius: 10,
            padding: 28, display: 'flex', flexDirection: 'column', justifyContent: 'space-between',
          }}>
            <div style={{ fontFamily: F.display, fontSize: isSquare ? 140 : 100, color: C.coral, lineHeight: 0.9, letterSpacing: '-1px' }}>{v}</div>
            <Eyebrow color={C.white} size={isSquare ? 14 : 11} ls="0.26em">{l}</Eyebrow>
          </div>
        ))}
      </div>
      <BottomRightMark bottom={pad - 10} right={pad} size={isSquare ? 36 : 30} />
    </>
  );
}

// ---------- C2 · Single Hero Stat ----------
function C2_SingleHero({ w, h, value = '4.5×', label = 'Average ROAS across 100+ D2C brands' }) {
  const isStory = h > w;
  const big = isStory ? 500 : 420;
  return (
    <>
      <GridBg />
      <CoralGlow size={isStory ? 1000 : 800} top="40%" left="50%" op={0.35} />
      <TopRightLogo top={44} right={44} height={24} />
      <Mark size={44} style={{ position: 'absolute', top: 48, left: 44 }} />

      <div style={{
        position: 'absolute', inset: 0,
        display: 'flex', flexDirection: 'column',
        alignItems: 'center', justifyContent: 'center', padding: '0 60px',
      }}>
        <Display size={big} color={C.coral} lh={0.85} ls="-5px">{value}</Display>
        <div style={{ marginTop: 20, maxWidth: isStory ? 800 : 700, textAlign: 'center' }}>
          <Eyebrow color={C.white} size={isStory ? 22 : 16} ls="0.32em">{label}</Eyebrow>
        </div>
      </div>
      <BottomLeftUrl bottom={isStory ? 80 : 40} fontSize={isStory ? 14 : 12} />
    </>
  );
}

// ---------- C3 · Revenue Counter ----------
function C3_RevenueCounter({ w, h }) {
  const isSquare = w === h;
  return (
    <>
      <GridBg />
      <TopLeftLogo top={44} left={44} height={22} />
      <div style={{ position: 'absolute', top: 44, right: 44 }}>
        <Pill tone="coralFill" size="sm">Real Client · 2025</Pill>
      </div>

      <div style={{
        position: 'absolute', inset: 0,
        display: 'flex', flexDirection: 'column',
        alignItems: 'center', justifyContent: 'center', padding: '0 40px',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: isSquare ? 30 : 20 }}>
          <Display size={isSquare ? 240 : 170} color={C.muted} lh={0.9} ls="-2px">$0</Display>
          <svg width={isSquare ? 90 : 60} height={isSquare ? 50 : 36} viewBox="0 0 60 30" fill="none">
            <path d="M5 15h45M40 5l12 10-12 10" stroke={C.coral} strokeWidth="4" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
          <Display size={isSquare ? 240 : 170} color={C.coral} lh={0.9} ls="-2px">$17.9M</Display>
        </div>
        <div style={{ marginTop: 28 }}>
          <Eyebrow color={C.white} size={isSquare ? 18 : 14} ls="0.3em">From Email Alone · 12 Months</Eyebrow>
        </div>
        <Body size={isSquare ? 14 : 12} color={C.muted} style={{ marginTop: 10 }}>
          URC Beverages × Sorted · Klaviyo engagement
        </Body>
      </div>
    </>
  );
}

// ---------- C4 · Ticker Strip ----------
function C4_TickerStrip({ w, h }) {
  const items = [
    ['100+', 'Brands'],
    ['$40M', 'Revenue'],
    ['4.5×', 'ROAS'],
    ['9', 'AI Agents'],
    ['72hr', 'Deploy'],
    ['40%', 'Cost Reduction'],
  ];
  return (
    <>
      <GridBg />
      <div style={{ position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column' }}>
        <div style={{ flex: 1, padding: '40px 60px' }}>
          <Eyebrow size={12} ls="0.32em">Sorted · Live Ticker</Eyebrow>
          <Display size={70} color={C.white} lh={0.9} style={{ marginTop: 12 }}>The numbers don't lie.</Display>
          <Body size={15} color={C.bodySoft} style={{ marginTop: 10, maxWidth: 700 }}>
            Live across 100+ D2C brands, measured against real dashboards — Shopify, Klaviyo, Meta, Google.
          </Body>
        </div>

        {/* coral ticker strip */}
        <div style={{
          background: C.coral, padding: '22px 0',
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          overflow: 'hidden',
        }}>
          {items.map(([v, l], i) => (
            <React.Fragment key={i}>
              <div style={{ display: 'flex', alignItems: 'baseline', gap: 10, padding: '0 22px' }}>
                <div style={{ fontFamily: F.display, fontSize: 40, color: '#fff', letterSpacing: '0.5px', lineHeight: 1 }}>{v}</div>
                <div style={{ fontFamily: F.body, fontSize: 12, fontWeight: 700, color: 'rgba(255,255,255,0.9)', letterSpacing: '0.2em', textTransform: 'uppercase' }}>{l}</div>
              </div>
              {i < items.length - 1 && <div style={{ width: 6, height: 6, borderRadius: '50%', background: 'rgba(255,255,255,0.6)' }} />}
            </React.Fragment>
          ))}
        </div>
      </div>
      <TopRightLogo top={40} right={40} height={22} />
    </>
  );
}

// ---------- C5 · Speed Stat ----------
function C5_SpeedStat({ w, h }) {
  const isSquare = w === h;
  return (
    <>
      <GridBg />
      <TopLeftLogo top={44} left={44} height={22} />
      <CoralGlow size={700} bottom="-20%" right="-20%" op={0.3} />

      <div style={{
        position: 'absolute', inset: 0,
        display: 'flex', flexDirection: 'column', justifyContent: 'center',
        padding: isSquare ? '0 60px' : '0 80px',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 20 }}>
          {/* clock icon */}
          <svg width={isSquare ? 72 : 52} height={isSquare ? 72 : 52} viewBox="0 0 48 48" fill="none">
            <circle cx="24" cy="24" r="20" stroke={C.coral} strokeWidth="3"/>
            <path d="M24 10v14l10 6" stroke={C.coral} strokeWidth="3" strokeLinecap="round"/>
          </svg>
          <Eyebrow color={C.coral} size={isSquare ? 16 : 12} ls="0.32em">From Kickoff to Live</Eyebrow>
        </div>

        <Display size={isSquare ? 340 : 240} color={C.white} lh={0.88} ls="-3px" style={{ marginTop: 14 }}>72 Hours.</Display>
        <Body size={isSquare ? 18 : 15} color={C.bodySoft} style={{ marginTop: 18, maxWidth: 700 }}>
          Audit, strategy, creative, Klaviyo flows and live Meta campaigns. Not weeks. Not months. Three days.
        </Body>
      </div>
      <BottomRightMark bottom={44} right={44} />
    </>
  );
}

// ---------- C6 · AI Peshwa Swarm ----------
function C6_PeshwaSwarm({ w, h }) {
  const isSquare = w === h;
  const cx = isSquare ? 540 : 600, cy = isSquare ? 540 : 340;
  const rad = isSquare ? 220 : 170;
  const agents = [
    'Ads', 'Klaviyo', 'Creative', 'Analytics', 'SEO', 'Shopify', 'CX', 'Research', 'Ops',
  ];

  return (
    <>
      <GridBg />
      <CoralGlow size={700} top="50%" left="50%" op={0.3} />
      <TopLeftLogo top={44} left={44} height={22} />
      <div style={{ position: 'absolute', top: 44, right: 44 }}>
        <Pill tone="coral" size="sm">Peshwa Swarm</Pill>
      </div>

      <svg viewBox={`0 0 ${isSquare ? 1080 : 1200} ${isSquare ? 1080 : 627}`}
           width="100%" height="100%"
           style={{ position: 'absolute', inset: 0 }}>
        {/* connection lines */}
        {agents.map((a, i) => {
          const angle = (i / agents.length) * Math.PI * 2 - Math.PI / 2;
          const x = cx + Math.cos(angle) * rad;
          const y = cy + Math.sin(angle) * rad;
          return <line key={'l'+i} x1={cx} y1={cy} x2={x} y2={y} stroke={C.coral} strokeWidth="1" opacity="0.25" />;
        })}
        {/* orbit rings */}
        <circle cx={cx} cy={cy} r={rad} fill="none" stroke={C.coral} strokeWidth="1" opacity="0.2" strokeDasharray="4 6"/>
        <circle cx={cx} cy={cy} r={rad - 70} fill="none" stroke={C.coral} strokeWidth="1" opacity="0.12" />

        {/* central CMD */}
        <circle cx={cx} cy={cy} r="56" fill={C.coral}/>
        <circle cx={cx} cy={cy} r="56" fill="none" stroke="#fff" strokeOpacity="0.25" strokeWidth="2"/>
        <text x={cx} y={cy+6} textAnchor="middle" fill="#fff"
              style={{ fontFamily: F.display, fontSize: 26, letterSpacing: '1px' }}>CMD</text>

        {/* agent nodes */}
        {agents.map((a, i) => {
          const angle = (i / agents.length) * Math.PI * 2 - Math.PI / 2;
          const x = cx + Math.cos(angle) * rad;
          const y = cy + Math.sin(angle) * rad;
          return (
            <g key={'n'+i}>
              <circle cx={x} cy={y} r="32" fill={C.navyLight} stroke={C.coral} strokeWidth="1.5"/>
              <text x={x} y={y+4} textAnchor="middle" fill={C.white}
                    style={{ fontFamily: F.body, fontSize: 11, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase' }}>{a}</text>
            </g>
          );
        })}
      </svg>

      <div style={{
        position: 'absolute', bottom: isSquare ? 80 : 40, left: 60,
      }}>
        <Display size={isSquare ? 90 : 60} color={C.white} lh={0.9}>9 AI Agents.</Display>
        <Body size={isSquare ? 15 : 13} color={C.muted} style={{ marginTop: 6 }}>Working while you sleep.</Body>
      </div>
    </>
  );
}

// ---------- C7 · Cost Reduction ----------
function C7_CostReduction({ w, h }) {
  return (
    <>
      <GridBg />
      <TopLeftLogo top={40} left={40} height={22} />

      <div style={{
        position: 'absolute', left: 60, right: 60, top: '50%',
        transform: 'translateY(-50%)',
        display: 'flex', alignItems: 'center', gap: 50,
      }}>
        {/* arrow */}
        <svg width="80" height="140" viewBox="0 0 80 140" fill="none">
          <path d="M40 10v110M15 95l25 25 25-25" stroke={C.coral} strokeWidth="6" strokeLinecap="round" strokeLinejoin="round"/>
        </svg>

        <div style={{ flex: 1 }}>
          <Eyebrow size={13} ls="0.3em">vs Traditional Agency Model</Eyebrow>
          <Display size={130} color={C.coral} lh={0.88} ls="-1px" style={{ marginTop: 10 }}>40% Cost Reduction.</Display>
          <Body size={16} color={C.bodySoft} style={{ marginTop: 16, maxWidth: 700 }}>
            Via AI automation. Same outcomes, half the overhead. <span style={{ color: C.white, fontWeight: 700 }}>Peshwa Swarm</span> replaces entire reporting departments.
          </Body>
        </div>
      </div>
      <BottomRightMark bottom={40} right={40} size={36} />
    </>
  );
}

// ---------- C8 · Agencies vs Sorted ----------
function C8_VsTable({ w, h }) {
  const isSquare = w === h;
  const pad = 40;
  const rows = [
    ['Model',     'Retainer + Hours',   'Outcome-based'],
    ['Team',      'Siloed, rotating',    '9 AI agents + lead'],
    ['Speed',     '4–8 week onboarding', '72 hour deploy'],
    ['Reporting', 'Monthly PDF',         'Live dashboard 24/7'],
    ['AI',        'Bolt-on Chat tool',    'Embedded Peshwa Swarm'],
    ['Coverage',  'Single channel',      'Full D2C stack'],
  ];
  return (
    <>
      <GridBg />
      <div style={{
        position: 'absolute', top: pad, left: pad, right: pad,
        display: 'flex', justifyContent: 'space-between', alignItems: 'center',
      }}>
        <Display size={isSquare ? 54 : 40} color={C.white} lh={0.9}>Agencies vs Sorted.</Display>
        <Logo height={22} />
      </div>

      <div style={{
        position: 'absolute', left: pad, right: pad,
        top: pad + (isSquare ? 100 : 70), bottom: pad,
        background: C.navyLight, borderRadius: 12,
        border: `1px solid ${C.border}`,
        padding: 0, overflow: 'hidden',
      }}>
        {/* header */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1.3fr 1.3fr',
          background: 'rgba(255,255,255,0.03)',
          borderBottom: `1px solid ${C.border}`,
        }}>
          <div style={{ padding: '14px 20px' }}><Eyebrow color={C.muted} size={11}>Dimension</Eyebrow></div>
          <div style={{ padding: '14px 20px', borderLeft: `1px solid ${C.border}` }}>
            <Eyebrow color={C.muted} size={11}>Most Agencies ✗</Eyebrow>
          </div>
          <div style={{ padding: '14px 20px', borderLeft: `1px solid ${C.border}`, background: 'rgba(232,38,75,0.08)' }}>
            <Eyebrow color={C.coral} size={11}>Sorted ✓</Eyebrow>
          </div>
        </div>

        {rows.map(([k, v1, v2], i) => (
          <div key={i} style={{
            display: 'grid', gridTemplateColumns: '1fr 1.3fr 1.3fr',
            borderBottom: i < rows.length - 1 ? `1px solid ${C.border}` : 'none',
          }}>
            <div style={{ padding: '14px 20px', display: 'flex', alignItems: 'center' }}>
              <Body size={isSquare ? 14 : 12} color={C.white} weight={700}>{k}</Body>
            </div>
            <div style={{ padding: '14px 20px', borderLeft: `1px solid ${C.border}`, display: 'flex', alignItems: 'center', gap: 10 }}>
              <span style={{ color: C.muted, fontSize: 14, fontWeight: 700 }}>×</span>
              <Body size={isSquare ? 14 : 12} color={C.muted}>{v1}</Body>
            </div>
            <div style={{ padding: '14px 20px', borderLeft: `1px solid ${C.border}`, display: 'flex', alignItems: 'center', gap: 10, background: 'rgba(232,38,75,0.04)' }}>
              <span style={{ color: C.coral, fontSize: 14, fontWeight: 700 }}>✓</span>
              <Body size={isSquare ? 14 : 12} color={C.white}>{v2}</Body>
            </div>
          </div>
        ))}
      </div>
    </>
  );
}

// ---------- C9 · Dashboard Screenshot ----------
function C9_Dashboard({ w, h }) {
  const isSquare = w === h;
  const topH = '55%';
  return (
    <>
      <GridBg />
      <TopLeftLogo top={30} left={40} height={20} />
      <div style={{ position: 'absolute', top: 30, right: 40 }}>
        <Pill tone="coralFill" size="sm">Real Data</Pill>
      </div>

      <div style={{
        position: 'absolute', top: 80, left: 40, right: 40,
        height: `calc(${topH} - 20px)`,
      }}>
        <PhotoPlaceholder h="100%" label="Drop Klaviyo / Shopify / GSC dashboard screenshot" />
      </div>

      <div style={{
        position: 'absolute', left: 40, right: 40,
        top: `calc(${topH} + 80px)`, bottom: 30,
        display: 'flex', flexDirection: 'column', justifyContent: 'center',
      }}>
        <Display size={isSquare ? 110 : 80} color={C.coral} lh={0.9} ls="-1px">$40M+ Tracked.</Display>
        <Body size={isSquare ? 15 : 13} color={C.muted} style={{ marginTop: 8 }}>
          Real numbers. Real client accounts. Live dashboards, not slide decks.
        </Body>
      </div>
    </>
  );
}

// ---------- C10 · 5 Rolling Stats (Story) ----------
// Render as 5 frames laid out vertically for review. Each frame is 1080×1920.
function C10_RollingStats() {
  const frames = [
    { v: '100+', l: 'D2C Brands Scaled' },
    { v: '$40M+', l: 'Revenue Tracked' },
    { v: '4.5×', l: 'Average ROAS' },
    { v: '9', l: 'AI Agents Deployed' },
    { v: '72hr', l: 'Kickoff to Live' },
  ];
  return frames;
}

// Per-frame renderer
function C10_Frame({ v, l, i, total }) {
  const w = 1080, h = 1920;
  return (
    <Artboard code={`C10·${String(i+1).padStart(2,'0')}`} platform="STORY" w={w} h={h} label={`Frame ${i+1}/${total}`}>
      <GridBg />
      <CoralGlow size={1100} top="50%" left="50%" op={0.3} />

      {/* progress bars */}
      <div style={{
        position: 'absolute', top: 80, left: 60, right: 60,
        display: 'flex', gap: 8,
      }}>
        {Array.from({ length: total }).map((_, j) => (
          <div key={j} style={{
            flex: 1, height: 3, borderRadius: 2,
            background: j <= i ? C.coral : 'rgba(255,255,255,0.12)',
          }} />
        ))}
      </div>

      <Mark size={56} style={{ position: 'absolute', top: 120, left: 60 }} />
      <div style={{ position: 'absolute', top: 135, right: 60 }}>
        <Eyebrow size={14} ls="0.3em">Sorted · {String(i+1).padStart(2,'0')}/05</Eyebrow>
      </div>

      <div style={{
        position: 'absolute', inset: 0,
        display: 'flex', flexDirection: 'column',
        alignItems: 'center', justifyContent: 'center', padding: '0 80px',
      }}>
        <Display size={540} color={C.coral} lh={0.85} ls="-6px">{v}</Display>
        <div style={{ marginTop: 30 }}>
          <Eyebrow color={C.white} size={26} ls="0.32em">{l}</Eyebrow>
        </div>
      </div>

      <BottomLeftUrl bottom={80} left={60} fontSize={16} />
      <Logo height={28} style={{ position: 'absolute', bottom: 74, right: 60 }} />
    </Artboard>
  );
}

function C10_AllFrames() {
  const frames = C10_RollingStats();
  return (
    <TemplateGroup code="C10" name="5 Rolling Stats" note="IG Story — 5 frames">
      {frames.map((f, i) => <C10_Frame key={i} {...f} i={i} total={frames.length} />)}
    </TemplateGroup>
  );
}

Object.assign(window, {
  C1_FourStatGrid, C2_SingleHero, C3_RevenueCounter, C4_TickerStrip,
  C5_SpeedStat, C6_PeshwaSwarm, C7_CostReduction, C8_VsTable,
  C9_Dashboard, C10_AllFrames,
});
