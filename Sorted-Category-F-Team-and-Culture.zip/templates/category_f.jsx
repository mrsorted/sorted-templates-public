// ============================================================
// Category F — Team & Culture (10 templates)
// ============================================================

function F1_Welcome({ w, h }) {
  return (<>
    <GridBg />
    <CoralGlow size={700} top="50%" left="50%" op={0.25} />
    <TopLeftLogo top={40} left={40} height={22} />

    {/* confetti dots */}
    {[[80,100,8],[1000,140,6],[150,900,10],[950,950,7],[40,500,5],[1040,600,6]].map(([x,y,r],i)=>(
      <div key={i} style={{ position: 'absolute', left: x, top: y, width: r, height: r, borderRadius: '50%', background: C.coral, opacity: 0.7 }}/>
    ))}

    <div style={{ position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: '0 60px', textAlign: 'center' }}>
      <Eyebrow color={C.coral} size={14} ls="0.32em">Welcome to the team</Eyebrow>
      <div style={{ marginTop: 20 }}>
        <AvatarPlaceholder size={300} label="Drop new hire photo" />
      </div>
      <Display size={80} color={C.white} lh={0.9} style={{ marginTop: 24 }}>[Name]</Display>
      <Body size={16} color={C.bodySoft} style={{ marginTop: 6 }}>[Role] · Sorted Squad</Body>
      <Body size={13} color={C.muted} style={{ marginTop: 10, fontStyle: 'italic' }}>Fun fact: [something about them]</Body>
    </div>
  </>);
}

function F2_Spotlight({ w, h }) {
  return (<>
    <GridBg />
    <div style={{ position: 'absolute', inset: '40px 40px 40px 40px', display: 'grid', gridTemplateColumns: '40% 1fr', gap: 28 }}>
      <PhotoPlaceholder h="100%" label="Drop team photo" />
      <div style={{ display: 'flex', flexDirection: 'column', padding: '20px 0' }}>
        <Eyebrow>Team Spotlight</Eyebrow>
        <Display size={80} color={C.white} lh={0.9} style={{ marginTop: 14 }}>Meet [Name]</Display>
        <Body size={16} color={C.bodySoft} style={{ marginTop: 8 }}>[Role]</Body>
        <Body size={15} color={C.white} lh={1.5} style={{ marginTop: 20, fontStyle: 'italic' }}>
          "I didn't join an agency. I joined a growth system."
        </Body>
        <Body size={13} color={C.muted} style={{ marginTop: 14 }}>
          Part of the Sorted squad since 2024.
        </Body>
        <div style={{ marginTop: 'auto' }}><Logo height={22} /></div>
      </div>
    </div>
  </>);
}

function F3_Anniversary({ w, h }) {
  return (<>
    <GridBg />
    <CoralGlow size={600} top="50%" left="50%" op={0.25} />
    <TopLeftLogo top={40} left={40} height={22} />

    <div style={{ position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: '0 60px', textAlign: 'center' }}>
      <AvatarPlaceholder size={200} label="Drop headshot" />
      <Display size={110} color={C.coral} lh={0.9} style={{ marginTop: 24 }}>3 Years at Sorted.</Display>
      <div style={{ display: 'flex', gap: 16, marginTop: 28 }}>
        {[1,2,3].map(y=>(
          <div key={y} style={{ width: 16, height: 16, borderRadius: '50%', background: C.coral }}/>
        ))}
        {[4,5].map(y=>(
          <div key={y} style={{ width: 16, height: 16, borderRadius: '50%', border: `2px solid ${C.muted}` }}/>
        ))}
      </div>
      <Body size={15} color={C.bodySoft} style={{ marginTop: 28 }}>Thank you for building this with us.</Body>
    </div>
  </>);
}

function F4_Hiring({ w, h }) {
  const isSquare = w === h;
  return (<>
    <GridBg />
    <TopLeftLogo top={40} left={40} height={22} />
    <div style={{ position: 'absolute', top: 40, right: 40 }}><Pill tone="coralFill">We're Hiring</Pill></div>

    <div style={{ position: 'absolute', inset: isSquare ? '120px 50px 50px' : '90px 50px 50px', display: 'grid', gridTemplateColumns: '1.2fr 1fr', gap: 30 }}>
      <div>
        <Display size={isSquare ? 90 : 64} color={C.white} lh={0.9}>Senior Performance Marketer.</Display>
        <Body size={14} color={C.coral} weight={700} style={{ marginTop: 10, letterSpacing: '0.2em', textTransform: 'uppercase' }}>Remote · Full-time · Mumbai / Dubai</Body>
        <div style={{ marginTop: 20, display: 'flex', flexDirection: 'column', gap: 10 }}>
          {['5+ years Meta + Google', 'Klaviyo certified preferred', 'Loud opinions on creative testing'].map(t=>(
            <div key={t} style={{ display: 'flex', gap: 10, alignItems: 'flex-start' }}>
              <div style={{ width: 6, height: 6, borderRadius: '50%', background: C.coral, marginTop: 10, flexShrink: 0 }}/>
              <Body size={14} color={C.bodySoft}>{t}</Body>
            </div>
          ))}
        </div>
        <div style={{ marginTop: 26 }}><CtaButton>Apply at sorted.agency</CtaButton></div>
      </div>
      <PhotoPlaceholder h="100%" label="Drop team photo" />
    </div>
  </>);
}

function F5_TeamOuting({ w, h }) {
  return (<>
    <div style={{ position: 'absolute', top: 0, left: 0, right: 0, height: '70%' }}>
      <PhotoPlaceholder h="100%" w="100%" label="Drop team outing / event photo" rounded={0} />
    </div>
    <div style={{ position: 'absolute', left: 0, right: 0, bottom: 0, height: '32%', background: C.navy, padding: '30px 50px', display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
      <Eyebrow>The Sorted Squad · Goa · 2025</Eyebrow>
      <Display size={64} color={C.white} lh={0.9} style={{ marginTop: 10 }}>The squad.</Display>
      <Logo height={22} style={{ position: 'absolute', top: 30, right: 50 }}/>
    </div>
  </>);
}

function F6_Headcount({ w, h }) {
  return (<>
    <GridBg />
    <TopLeftLogo top={40} left={40} height={22} />
    <div style={{ position: 'absolute', top: 100, left: 60, right: 60, textAlign: 'center' }}>
      <Display size={110} color={C.coral} lh={0.9}>We're now 34 strong.</Display>
      <Body size={14} color={C.muted} style={{ marginTop: 10 }}>And we're growing.</Body>
    </div>
    <div style={{ position: 'absolute', left: 80, right: 80, top: 360, bottom: 120, display: 'grid', gridTemplateColumns: 'repeat(5,1fr)', gridTemplateRows: 'repeat(2,1fr)', gap: 18, justifyItems: 'center', alignItems: 'center' }}>
      {Array.from({length: 9}).map((_,i)=> <AvatarPlaceholder key={i} size={120} label="Headshot" />)}
      <div style={{ width: 120, height: 120, borderRadius: '50%', border: `2px dashed ${C.coral}`, background: C.navyLight, display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: F.display, fontSize: 28, color: C.coral }}>+25</div>
    </div>
    <div style={{ position: 'absolute', bottom: 40, left: 0, right: 0, textAlign: 'center' }}>
      <CtaButton size="md">See open roles</CtaButton>
    </div>
  </>);
}

function F7_BehindTheScenes({ w, h }) {
  const captions = ['Mumbai HQ', 'Creative war room', 'Friday demo day', 'Offsite · Goa'];
  return (<>
    <GridBg />
    <TopLeftLogo top={40} left={40} height={22} />
    <div style={{ position: 'absolute', top: 40, right: 40 }}><Eyebrow>Inside Sorted</Eyebrow></div>
    <div style={{ position: 'absolute', top: 100, left: 60 }}>
      <Display size={72} color={C.white} lh={0.9}>Inside Sorted.</Display>
    </div>
    <div style={{ position: 'absolute', left: 60, right: 60, top: 240, bottom: 60, display: 'grid', gridTemplateColumns: 'repeat(2,1fr)', gridTemplateRows: 'repeat(2,1fr)', gap: 16 }}>
      {captions.map((c,i)=>(
        <div key={i} style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          <PhotoPlaceholder h="100%" label={`Drop ${c.toLowerCase()} photo`} />
          <Eyebrow size={11}>{c}</Eyebrow>
        </div>
      ))}
    </div>
  </>);
}

function F8_Play({ w, h }) {
  return (<>
    <GridBg />
    <TopLeftLogo top={40} left={40} height={22} />
    <div style={{ position: 'absolute', top: 80, left: 60 }}>
      <Eyebrow color={C.muted}>All work and no play…</Eyebrow>
    </div>
    <div style={{ position: 'absolute', top: 150, left: 60, right: 60, bottom: 200 }}>
      <PhotoPlaceholder h="100%" label="Drop team games / outing photo" />
    </div>
    <div style={{ position: 'absolute', bottom: 60, left: 60 }}>
      <Display size={100} color={C.coral} lh={0.9}>We do both.</Display>
    </div>
  </>);
}

function F9_TeamWin({ w, h }) {
  return (<>
    <GridBg />
    <CoralGlow size={500} top="50%" left="50%" op={0.25} />
    <TopLeftLogo top={40} left={40} height={22} />
    <div style={{ position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: '0 80px', textAlign: 'center' }}>
      <svg width="80" height="80" viewBox="0 0 48 48" fill="none">
        <path d="M24 34c7-2 12-8 12-16V8H12v10c0 8 5 14 12 16zM20 40h8M24 34v6" stroke={C.coral} strokeWidth="2.5" strokeLinecap="round"/>
      </svg>
      <Eyebrow color={C.coral} size={14} ls="0.3em" style={{ marginTop: 16 }}>Team Win</Eyebrow>
      <Display size={90} color={C.white} lh={0.92} style={{ marginTop: 12 }}>Shipped 7 Klaviyo rebuilds in one week.</Display>
      <div style={{ display: 'flex', gap: 12, marginTop: 32 }}>
        {[1,2,3].map(i=><AvatarPlaceholder key={i} size={72} label="Headshot" />)}
      </div>
      <Body size={13} color={C.muted} style={{ marginTop: 18 }}>Nov 2025 · The retention pod</Body>
    </div>
  </>);
}

function F10_Values({ w, h }) {
  const vals = [
    ['Direct',   '→', 'No soft-pedalling.'],
    ['Specific', '⟡', 'Numbers over narrative.'],
    ['Honest',   '◇', 'If it\'s broken, we say so.'],
    ['Bold',     '✦', 'Play offence, not defence.'],
  ];
  return (<>
    <GridBg />
    <TopLeftLogo top={40} left={40} height={22} />
    <div style={{ position: 'absolute', inset: '100px 50px 50px', display: 'grid', gridTemplateColumns: '1.2fr 1fr', gap: 30 }}>
      <div>
        <Display size={72} color={C.white} lh={0.9}>Why Sorted?</Display>
        <div style={{ marginTop: 30, display: 'flex', flexDirection: 'column', gap: 14 }}>
          {vals.map(([v, icon, s],i)=>(
            <div key={i} style={{ display: 'flex', gap: 16, alignItems: 'baseline' }}>
              <div style={{ color: C.coral, fontSize: 22, width: 28 }}>{icon}</div>
              <div>
                <div style={{ fontFamily: F.display, fontSize: 36, color: C.white }}>{v}</div>
                <Body size={13} color={C.muted} style={{ marginTop: 2 }}>{s}</Body>
              </div>
            </div>
          ))}
        </div>
        <div style={{ marginTop: 26 }}><CtaButton>Join us</CtaButton></div>
      </div>
      <PhotoPlaceholder h="100%" label="Drop office / team photo" />
    </div>
  </>);
}

Object.assign(window, { F1_Welcome, F2_Spotlight, F3_Anniversary, F4_Hiring, F5_TeamOuting, F6_Headcount, F7_BehindTheScenes, F8_Play, F9_TeamWin, F10_Values });
