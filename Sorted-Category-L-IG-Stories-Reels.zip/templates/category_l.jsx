// Category L — IG Stories & Reels (6)
function L1_StoryStat({w,h}){return(<>
<GridBg/><CoralGlow size={1100} top="50%" left="50%" op={0.35}/>
<Mark size={60} style={{position:'absolute',top:120,left:60}}/>
<div style={{position:'absolute',top:130,right:60}}><Eyebrow size={14} ls="0.32em">Sorted · 2025</Eyebrow></div>
<div style={{position:'absolute',inset:0,display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',padding:'0 80px',textAlign:'center'}}>
<Display size={540} color={C.coral} lh={0.85} ls="-6px">4.5×</Display>
<Eyebrow color={C.white} size={26} ls="0.32em" style={{marginTop:30}}>Average ROAS</Eyebrow>
<Body size={18} color={C.bodySoft} style={{marginTop:14}}>across 100+ D2C brands</Body>
<div style={{marginTop:60}}>
<div style={{padding:'16px 40px',border:`2px solid ${C.coral}`,borderRadius:999,color:C.coral,fontFamily:F.body,fontWeight:700,fontSize:16,letterSpacing:'0.2em',textTransform:'uppercase'}}>Swipe Up ↑</div>
</div></div>
<BottomLeftUrl bottom={80} left={60} fontSize={16}/>
<Logo height={28} style={{position:'absolute',bottom:74,right:60}}/>
</>);}

function L2_StoryTip({w,h}){return(<>
<GridBg/>
<div style={{position:'absolute',top:100,left:60}}><Mark size={50}/></div>
<div style={{position:'absolute',top:110,right:60}}><Pill tone="coralFill" size="md">Sorted Tip #07</Pill></div>
<div style={{position:'absolute',left:80,right:80,top:280}}>
<Display size={52} color={C.white} lh={1.1}>Your welcome email should send in under 60 seconds.</Display>
<Body size={18} color={C.bodySoft} lh={1.5} style={{marginTop:26}}>
Not 1 hour. Not "end of day". Sub-60-second opens 3× higher. Split tests every time.
</Body></div>
<div style={{position:'absolute',left:60,right:60,top:900,bottom:200}}><PhotoPlaceholder h="100%" label="Drop relevant visual"/></div>
<div style={{position:'absolute',left:0,right:0,bottom:0,background:C.coral,padding:'22px 60px',display:'flex',justifyContent:'space-between',alignItems:'center'}}>
<Body size={14} color="#fff" weight={700} style={{letterSpacing:'0.28em',textTransform:'uppercase'}}>sorted.agency</Body>
<img src="assets/sorted-logo.png" alt="" style={{height:24,filter:'brightness(0) invert(1)'}}/>
</div></>);}

function L3_StoryThisOrThat({w,h}){return(<>
<GridBg/><Mark size={50} style={{position:'absolute',top:100,left:60}}/>
<div style={{position:'absolute',top:110,right:60}}><Eyebrow size={14} ls="0.32em">Tap to vote</Eyebrow></div>
<div style={{position:'absolute',top:250,left:80,right:80,textAlign:'center'}}>
<Display size={80} color={C.white} lh={0.95}>This or that?</Display></div>
<div style={{position:'absolute',left:80,right:80,top:460,display:'flex',flexDirection:'column',gap:30}}>
<div style={{background:C.navyLight,border:`2px solid ${C.coral}`,borderRadius:20,padding:60,textAlign:'center'}}>
<Eyebrow color={C.coral} size={14}>Option A</Eyebrow>
<Display size={90} color={C.white} style={{marginTop:14}}>More Ads</Display>
</div>
<div style={{fontFamily:F.display,fontSize:54,color:C.coral,textAlign:'center'}}>vs</div>
<div style={{background:C.navyLight,border:`2px solid ${C.coral}`,borderRadius:20,padding:60,textAlign:'center'}}>
<Eyebrow color={C.coral} size={14}>Option B</Eyebrow>
<Display size={90} color={C.white} style={{marginTop:14}}>Better Email</Display>
</div></div>
<BottomLeftUrl bottom={80} left={60} fontSize={16}/>
<Logo height={28} style={{position:'absolute',bottom:74,right:60}}/>
</>);}

function L4_QuestionBox({w,h}){return(<>
<GridBg/><CoralGlow size={900} top="50%" left="50%" op={0.25}/>
<Mark size={50} style={{position:'absolute',top:100,left:60}}/>
<div style={{position:'absolute',top:260,left:80,right:80,textAlign:'center'}}>
<Display size={72} color={C.white} lh={1}>Ask us anything about D2C growth.</Display>
<Body size={16} color={C.bodySoft} style={{marginTop:20}}>We answer everything. Even the dumb ones.</Body>
</div>
<div style={{position:'absolute',left:80,right:80,top:720,height:300,border:`2px dashed ${C.coral}`,borderRadius:20,background:'rgba(232,38,75,0.05)',display:'flex',alignItems:'center',justifyContent:'center'}}>
<Body size={18} color={C.muted} style={{fontStyle:'italic'}}>Drop IG Question Sticker here</Body></div>
<BottomLeftUrl bottom={80} left={60} fontSize={16}/>
<Logo height={28} style={{position:'absolute',bottom:74,right:60}}/>
</>);}

function L5_ReelCover({w,h}){return(<>
<GridBg/>
<div style={{position:'absolute',top:0,left:0,right:0,height:'40%',background:`linear-gradient(180deg, ${C.navy}, transparent)`,zIndex:2}}/>
<div style={{position:'absolute',top:50,left:50,right:50,zIndex:3}}>
<Display size={92} color={C.coral} lh={0.9}>Why your Klaviyo is broken.</Display>
<Body size={14} color={C.white} weight={700} style={{marginTop:12,letterSpacing:'0.28em',textTransform:'uppercase'}}>3 fixes · 60 seconds</Body>
</div>
<div style={{position:'absolute',left:50,right:50,top:450,bottom:120}}><PhotoPlaceholder h="100%" label="Drop face / action shot"/></div>
<div style={{position:'absolute',left:0,right:0,bottom:0,background:C.navy,borderTop:`2px solid ${C.coral}`,padding:'20px 50px',display:'flex',justifyContent:'space-between',alignItems:'center'}}>
<Logo height={22}/><Body size={12} color={C.muted} weight={700} style={{letterSpacing:'0.28em',textTransform:'uppercase'}}>Watch full reel →</Body>
</div></>);}

function L6_AuditCTA({w,h}){return(<>
<GridBg/><CoralGlow size={1200} top="50%" left="50%" op={0.45}/>
<Mark size={60} style={{position:'absolute',top:120,left:60}}/>
<div style={{position:'absolute',inset:0,display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',padding:'0 80px',textAlign:'center'}}>
<Eyebrow color={C.coral} size={16} ls="0.32em">Free For Founders</Eyebrow>
<Display size={220} color={C.white} lh={0.9} style={{marginTop:20}}>Free D2C Audit.</Display>
<Body size={20} color={C.bodySoft} style={{marginTop:24,maxWidth:800}}>
We'll audit your Meta, Klaviyo + Shopify in 45 minutes. No pitch. Just gaps.
</Body>
<div style={{marginTop:60,padding:'20px 50px',background:C.coral,borderRadius:999,boxShadow:'0 20px 60px -10px rgba(232,38,75,0.6)'}}>
<div style={{fontFamily:F.body,fontWeight:700,color:'#fff',fontSize:20,letterSpacing:'0.2em',textTransform:'uppercase'}}>Swipe Up ↑</div>
</div></div>
<BottomLeftUrl bottom={80} left={60} fontSize={16}/>
<Logo height={28} style={{position:'absolute',bottom:74,right:60}}/>
</>);}

Object.assign(window, {L1_StoryStat, L2_StoryTip, L3_StoryThisOrThat, L4_QuestionBox, L5_ReelCover, L6_AuditCTA});
