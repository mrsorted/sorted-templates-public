// ============================================================
// Category E — Thought Leadership (10 templates)
// ============================================================

function E1_DidYouKnow({ w, h }) {
  const isSquare = w === h;
  return (<>
    <GridBg />
    <TopLeftLogo top={40} left={40} height={22} />
    <div style={{ position: 'absolute', top: isSquare ? 120 : 80, left: 60 }}>
      <Pill tone="coralFill" size="md">Did You Know:</Pill>
    </div>
    <div style={{ position: 'absolute', left: 60, right: 60, top: isSquare ? 200 : 140, bottom: 100 }}>
      <Display size={isSquare ? 78 : 54} color={C.white} lh={0.95}>
        35–45% of D2C revenue should come from Klaviyo flows — not ads.
      </Display>
      <Body size={isSquare ? 14 : 12} color={C.muted} style={{ marginTop: 20 }}>
        Source: Klaviyo 2025 Benchmark Report · Sorted client avg: 42%
      </Body>
    </div>
    <BottomRightMark bottom={36} right={40} />
  </>);
}

function E2_HotTake({ w, h }) {
  const isSquare = w === h;
  return (<>
    <GridBg />
    <CoralGlow size={700} bottom="-20%" left="-20%" op={0.3} />
    <TopLeftLogo top={40} left={40} height={22} />
    <div style={{ position: 'absolute', top: isSquare ? 120 : 80, left: 60 }}>
      <Display size={isSquare ? 50 : 36} color={C.coral}>Hot Take:</Display>
    </div>
    <div style={{ position: 'absolute', left: 60, right: 60, top: isSquare ? 220 : 140 }}>
      <Display size={isSquare ? 110 : 76} color={C.white} lh={0.92}>
        If your agency sends PDF reports, you're their customer. Not their client.
      </Display>
      <Body size={isSquare ? 15 : 13} color={C.muted} style={{ marginTop: 24, fontStyle: 'italic' }}>— Sorted</Body>
    </div>
  </>);
}

function E3_MythReality({ w, h }) {
  return (<>
    <GridBg />
    <div style={{ position: 'absolute', left: '50%', top: 60, bottom: 60, width: 1, background: `linear-gradient(to bottom, transparent, ${C.coral}, transparent)`, transform: 'translateX(-50%)' }}/>
    <TopLeftLogo top={30} left={40} height={20} />
    <BottomRightMark bottom={20} right={40} size={32} />

    <div style={{ position: 'absolute', inset: '70px 40px 70px', display: 'grid', gridTemplateColumns: '1fr 1fr' }}>
      <div style={{ padding: '30px 36px' }}>
        <Eyebrow color={C.muted} size={13} ls="0.3em">Myth:</Eyebrow>
        <Display size={60} color={C.muted} lh={0.95} style={{ marginTop: 16, textDecoration: 'line-through', textDecorationColor: C.coral }}>
          More ad spend = more revenue.
        </Display>
      </div>
      <div style={{ padding: '30px 36px' }}>
        <Eyebrow color={C.coral} size={13} ls="0.3em">Reality:</Eyebrow>
        <Display size={60} color={C.white} lh={0.95} style={{ marginTop: 16 }}>
          Fix Klaviyo first. 40% cheaper revenue.
        </Display>
      </div>
    </div>
    <div style={{ position: 'absolute', bottom: 26, left: 0, right: 0, textAlign: 'center' }}>
      <Body size={12} color={C.coral} weight={700} style={{ letterSpacing: '0.28em', textTransform: 'uppercase' }}>What's your take? Comment ↓</Body>
    </div>
  </>);
}

function E4_ThreeStep({ w, h }) {
  const isSquare = w === h;
  const steps = [
    ['Audit',     'Klaviyo · Meta · Shopify in 45 min.'],
    ['Strategy',  '90-day roadmap with weekly milestones.'],
    ['Deploy',    'Flows live in 72 hours. Creative weekly.'],
  ];
  return (<>
    <GridBg />
    <TopLeftLogo top={40} left={40} height={22} />
    <div style={{ position: 'absolute', top: isSquare ? 100 : 70, left: 50, right: 50 }}>
      <Display size={isSquare ? 72 : 52} color={C.white} lh={0.9}>3-step framework.</Display>
    </div>
    <div style={{ position: 'absolute', left: 50, right: 50, top: isSquare ? 240 : 170, bottom: 80, display: 'flex', flexDirection: 'column', justifyContent: 'space-around', gap: 20 }}>
      {steps.map(([t, s], i)=>(
        <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 24 }}>
          <div style={{ width: 70, height: 70, borderRadius: '50%', background: C.coral, color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: F.display, fontSize: 32, flexShrink: 0 }}>{String(i+1).padStart(2,'0')}</div>
          <div style={{ flex: 1 }}>
            <div style={{ fontFamily: F.display, fontSize: isSquare ? 42 : 32, color: C.white, letterSpacing: '0.5px' }}>{t}</div>
            <Body size={isSquare ? 15 : 13} color={C.bodySoft} style={{ marginTop: 4 }}>{s}</Body>
          </div>
        </div>
      ))}
    </div>
    <div style={{ position: 'absolute', bottom: 30, right: 50 }}>
      <Body size={12} color={C.coral} weight={700} style={{ letterSpacing: '0.28em', textTransform: 'uppercase' }}>Save this 🔖</Body>
    </div>
  </>);
}

function E5_FounderQuote({ w, h }) {
  const isSquare = w === h;
  return (<>
    <GridBg />
    <div style={{ position: 'absolute', top: 60, left: 60, width: 3, bottom: 60, background: C.coral }}/>
    <TopRightLogo top={40} right={40} height={22} />

    <div style={{ position: 'absolute', left: 100, right: 60, top: isSquare ? 140 : 80, bottom: 140 }}>
      <Eyebrow size={12} ls="0.3em">Dhiraj Palekar · Founder, Sorted</Eyebrow>
      <Display size={isSquare ? 72 : 48} color={C.white} lh={1.05} style={{ marginTop: 20, fontStyle: 'italic' }}>
        "Most agencies sell hours. We sell outcomes. If you can't measure it, we can't charge for it."
      </Display>
    </div>

    <div style={{ position: 'absolute', bottom: 60, left: 100, display: 'flex', alignItems: 'center', gap: 16 }}>
      <AvatarPlaceholder size={64} label="Dhiraj headshot" />
      <div>
        <div style={{ fontFamily: F.body, fontSize: 14, fontWeight: 700, color: C.white }}>Dhiraj Palekar</div>
        <div style={{ fontFamily: F.body, fontSize: 12, color: C.muted }}>Founder · Sorted</div>
      </div>
    </div>
  </>);
}

function E6_TrendAlert({ w, h }) {
  const isSquare = w === h;
  return (<>
    <GridBg />
    <CoralGlow size={600} top="-20%" right="-20%" op={0.3} />
    <TopLeftLogo top={40} left={40} height={22} />

    <div style={{ position: 'absolute', top: isSquare ? 120 : 80, left: 60 }}>
      <Pill tone="coralFill" size="md">🚨 Trend Alert</Pill>
    </div>
    <div style={{ position: 'absolute', left: 60, right: 60, top: isSquare ? 210 : 140 }}>
      <Display size={isSquare ? 76 : 54} color={C.white} lh={0.95}>Meta CPMs are up 34% YoY. Email can't save you alone anymore.</Display>
      <Body size={isSquare ? 15 : 13} color={C.bodySoft} style={{ marginTop: 20 }}>
        Context: Q4 2025 CPMs hit $15+ for apparel. Retention + creative velocity + zero-party data is the only way out.
      </Body>
      <div style={{ marginTop: 22 }}>
        <Eyebrow color={C.coral}>What to do:</Eyebrow>
        <Body size={isSquare ? 15 : 13} color={C.white} weight={700} style={{ marginTop: 6 }}>
          Audit your top 3 flows. Re-cut 12 UGC creatives per month. Launch SMS.
        </Body>
      </div>
    </div>
  </>);
}

function E7_IndustryStat({ w, h }) {
  return (<>
    <GridBg />
    <div style={{ position: 'absolute', left: 0, top: 60, bottom: 60, width: 3, background: C.coral }}/>
    <TopLeftLogo top={30} left={40} height={20} />
    <div style={{ position: 'absolute', left: 60, right: 60, top: 90 }}>
      <Display size={130} color={C.coral} lh={0.88} ls="-1px">71% of D2C brands never recover abandoned carts.</Display>
      <Body size={15} color={C.bodySoft} style={{ marginTop: 20, maxWidth: 900 }}>
        That's an average $4,200 per month left on the table — for a brand doing $100K/month. A single Klaviyo flow, set up once, recovers 18–24% of them.
      </Body>
    </div>
    <div style={{ position: 'absolute', bottom: 30, left: 60 }}>
      <Body size={12} color={C.coral} weight={700} style={{ letterSpacing: '0.28em', textTransform: 'uppercase' }}>What this means for your brand →</Body>
    </div>
  </>);
}

function E8_ThisYou({ w, h }) {
  const items = [
    'Klaviyo is under 15% of revenue.',
    'Meta CAC has climbed 3 months straight.',
    'You check ROAS at 11pm. Again.',
    'Reporting is a PDF. Not a dashboard.',
    'You can\'t name your top 3 SKUs by LTV.',
  ];
  return (<>
    <GridBg />
    <TopLeftLogo top={40} left={40} height={22} />
    <div style={{ position: 'absolute', top: 100, left: 60 }}>
      <Display size={80} color={C.coral} lh={0.9}>This you?</Display>
    </div>
    <div style={{ position: 'absolute', left: 60, right: 60, top: 220, display: 'flex', flexDirection: 'column', gap: 14 }}>
      {items.map((t,i)=>(
        <div key={i} style={{ display: 'flex', gap: 14, alignItems: 'center', padding: '14px 20px', background: C.navyLight, border: `1px solid ${C.border}`, borderRadius: 8 }}>
          <div style={{ width: 22, height: 22, border: `2px solid ${C.coral}`, borderRadius: 4, flexShrink: 0 }}/>
          <Body size={15} color={C.white}>{t}</Body>
        </div>
      ))}
    </div>
    <div style={{ position: 'absolute', bottom: 60, left: 0, right: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 12 }}>
      <Body size={13} color={C.bodySoft} weight={700}>If you checked 3+, we need to talk.</Body>
      <CtaButton size="md">Book a Free Audit</CtaButton>
    </div>
  </>);
}

function E9_Definition({ w, h }) {
  return (<>
    <GridBg />
    <TopLeftLogo top={40} left={40} height={22} />
    <div style={{ position: 'absolute', top: 90, left: 60 }}>
      <Eyebrow size={13} ls="0.3em">Sorted · Glossary</Eyebrow>
      <Display size={70} color={C.white} lh={0.9} style={{ marginTop: 8 }}>What is a <span style={{ color: C.coral }}>Win-Back Flow</span>?</Display>
    </div>
    <div style={{ position: 'absolute', left: 60, right: 60, top: 260 }}>
      <Body size={17} color={C.bodySoft} lh={1.55}>
        A Klaviyo automation that re-engages customers who haven't purchased in 60–120 days, using progressive incentives — a reminder, then social proof, then a final 15% offer. Typically recovers 8–12% of lapsed customers.
      </Body>
    </div>
    <div style={{ position: 'absolute', bottom: 40, left: 60, right: 60, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
      <Body size={11} color={C.muted} weight={700} style={{ letterSpacing: '0.28em', textTransform: 'uppercase' }}>Sorted Glossary · Vol. 01</Body>
      <Logo height={18} />
    </div>
  </>);
}

function E10_HowTo4Steps({ w, h }) {
  const steps = [
    ['Audit Klaviyo', 'Pull last 90 days flow revenue. Identify the gap.'],
    ['Rebuild Welcome', '3 emails · 1 SMS · progressive offer.'],
    ['Add Browse + Cart', 'Behaviour triggers. 30-min delay.'],
    ['Split test subjects', 'Weekly A/B. Winning creative wins budget.'],
  ];
  return (<>
    <GridBg />
    <TopLeftLogo top={40} left={40} height={22} />
    <div style={{ position: 'absolute', top: 100, left: 60 }}>
      <Display size={72} color={C.white} lh={0.9}>How to 2× email revenue in 30 days.</Display>
    </div>
    <div style={{ position: 'absolute', left: 60, right: 60, top: 270, bottom: 80, display: 'grid', gridTemplateColumns: 'repeat(2,1fr)', gridTemplateRows: 'repeat(2,1fr)', gap: 14 }}>
      {steps.map(([t, s], i)=>(
        <div key={i} style={{ background: C.navyLight, border: `1px solid ${C.border}`, borderRadius: 10, padding: 20 }}>
          <div style={{ fontFamily: F.display, fontSize: 48, color: C.coral, lineHeight: 1 }}>{String(i+1).padStart(2,'0')}</div>
          <div style={{ fontFamily: F.display, fontSize: 26, color: C.white, marginTop: 6 }}>{t}</div>
          <Body size={13} color={C.bodySoft} style={{ marginTop: 8 }}>{s}</Body>
        </div>
      ))}
    </div>
    <div style={{ position: 'absolute', bottom: 30, right: 60 }}>
      <Body size={12} color={C.coral} weight={700} style={{ letterSpacing: '0.28em', textTransform: 'uppercase' }}>Save this for later 🔖</Body>
    </div>
  </>);
}

Object.assign(window, { E1_DidYouKnow, E2_HotTake, E3_MythReality, E4_ThreeStep, E5_FounderQuote, E6_TrendAlert, E7_IndustryStat, E8_ThisYou, E9_Definition, E10_HowTo4Steps });
