// Category G — Events & Occasions (8)
function G1_EventAnnounce({w,h}){return(<>
<GridBg/><CoralGlow size={500} top="-20%" right="-20%" op={0.3}/>
<TopLeftLogo top={40} left={40} height={22}/>
<div style={{position:'absolute',top:40,right:40}}><Pill tone="coralFill">Live Event</Pill></div>
<div style={{position:'absolute',inset:'120px 50px 50px',display:'grid',gridTemplateColumns:'1.2fr 1fr',gap:30}}>
<div>
<Eyebrow color={C.coral} size={14} ls="0.3em">Join us live</Eyebrow>
<Display size={72} color={C.white} lh={0.9} style={{marginTop:14}}>Scaling D2C in 2026: the Klaviyo playbook.</Display>
<div style={{marginTop:24,display:'flex',flexDirection:'column',gap:8}}>
{[['Date','Thu 12 Feb 2026'],['Time','6:00 PM IST · 12:30 PM GMT'],['Platform','Zoom · 60 min · free']].map(([k,v])=>(
<div key={k} style={{display:'flex',gap:12}}><Body size={12} color={C.muted} weight={700} style={{width:80,letterSpacing:'0.2em',textTransform:'uppercase'}}>{k}</Body><Body size={14} color={C.white}>{v}</Body></div>))}
</div>
<div style={{marginTop:24}}><CtaButton size="lg">Register Free</CtaButton></div>
</div>
<div style={{display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',gap:16}}>
<AvatarPlaceholder size={200} label="Speaker headshot"/>
<Body size={14} color={C.white} weight={700}>Dhiraj Palekar</Body>
<Body size={12} color={C.muted}>Founder · Sorted</Body>
</div></div></>);}

function G2_EventRecap({w,h}){return(<>
<div style={{position:'absolute',inset:0}}><PhotoPlaceholder h="100%" w="100%" label="Drop event / conference photo" rounded={0}/></div>
<div style={{position:'absolute',inset:0,background:'linear-gradient(180deg,rgba(9,24,43,0.3) 0%,rgba(9,24,43,0.05) 40%,rgba(9,24,43,0.95) 90%)'}}/>
<TopLeftLogo top={32} left={32} height={22}/>
<div style={{position:'absolute',bottom:40,left:50,right:50}}>
<Eyebrow color={C.coral} size={13} ls="0.3em">We were there · D2C Summit Mumbai 2025</Eyebrow>
<Display size={80} color={C.white} lh={0.9} style={{marginTop:10}}>The future is compounding.</Display>
<Body size={13} color={C.coral} weight={700} style={{marginTop:16,letterSpacing:'0.28em',textTransform:'uppercase'}}>Key takeaways 👇</Body>
</div></>);}

function G3_Speaking({w,h}){return(<>
<GridBg/><TopLeftLogo top={30} left={40} height={22}/>
<div style={{position:'absolute',inset:'80px 40px 40px',display:'grid',gridTemplateColumns:'1fr 1.2fr',gap:28}}>
<PhotoPlaceholder h="100%" label="Drop speaker / stage photo"/>
<div style={{display:'flex',flexDirection:'column',justifyContent:'center'}}>
<Eyebrow>Sorted · On Stage</Eyebrow>
<Display size={60} color={C.white} lh={0.9} style={{marginTop:12}}>Sorted at SaaSBoomi 2025.</Display>
<div style={{marginTop:22,display:'flex',flexDirection:'column',gap:12}}>
{['CPMs are up. Creative velocity wins.','Email is 40%+ of revenue, or you\'re behind.','AI eats reporting. Humans keep strategy.'].map((t,i)=>(
<div key={i} style={{display:'flex',gap:10,alignItems:'flex-start'}}><div style={{width:6,height:6,borderRadius:'50%',background:C.coral,marginTop:8,flexShrink:0}}/><Body size={13} color={C.white}>{t}</Body></div>))}
</div>
<Body size={12} color={C.coral} weight={700} style={{marginTop:20,letterSpacing:'0.28em',textTransform:'uppercase'}}>Catch us at the next one →</Body>
</div></div></>);}

function G4_Kickoff({w,h}){return(<>
<GridBg/><CoralGlow size={600} bottom="-30%" right="-30%" op={0.3}/>
<TopLeftLogo top={40} left={40} height={22}/>
<div style={{position:'absolute',top:80,left:50,right:50,height:'45%'}}>
<PhotoPlaceholder h="100%" label="Drop kickoff meeting / team photo"/></div>
<div style={{position:'absolute',left:50,right:50,bottom:60}}>
<Display size={120} color={C.white} lh={0.88}>And so it begins.</Display>
<Body size={14} color={C.muted} style={{marginTop:14}}>[Client] campaign goes live in 72 hours.</Body>
</div></>);}

function G5_Award({w,h}){return(<>
<GridBg/><CoralGlow size={600} top="50%" left="50%" op={0.25}/>
<TopLeftLogo top={40} left={40} height={22}/>
<div style={{position:'absolute',inset:0,display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',padding:'0 60px',textAlign:'center'}}>
<svg width="80" height="80" viewBox="0 0 48 48" fill="none"><path d="M24 32c7-2 12-8 12-16V6H12v10c0 8 5 14 12 16zM18 40h12M24 32v8" stroke={C.coral} strokeWidth="2.5"/></svg>
<Eyebrow color={C.coral} size={14} ls="0.3em" style={{marginTop:18}}>Recognition · 2025</Eyebrow>
<Display size={90} color={C.white} lh={0.9} style={{marginTop:14}}>We won Agency of the Year.</Display>
<Body size={14} color={C.bodySoft} style={{marginTop:12}}>Performance Marketing · D2C Circle Awards</Body>
<div style={{marginTop:30}}><PhotoPlaceholder h={180} w={280} label="Drop award photo"/></div>
</div></>);}

function G6_Office({w,h}){return(<>
<GridBg/><TopLeftLogo top={40} left={40} height={22}/>
<div style={{position:'absolute',top:40,right:40}}><Pill tone="coralFill">Carousel · 03</Pill></div>
<div style={{position:'absolute',inset:'110px 50px 50px',display:'grid',gridTemplateRows:'1fr 1fr 1fr',gap:14}}>
{[['Drop exterior / entrance photo','Sorted HQ · Mumbai'],['Drop desk / workspace photo','Where the work happens'],['Drop team gathered photo','Come work with us →']].map(([p,c],i)=>(
<div key={i} style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:14}}>
<PhotoPlaceholder h="100%" label={p}/>
<div style={{display:'flex',flexDirection:'column',justifyContent:'center',padding:'0 10px'}}>
<div style={{fontFamily:F.display,fontSize:18,color:C.coral}}>{String(i+1).padStart(2,'0')} / 03</div>
<div style={{fontFamily:F.display,fontSize:32,color:C.white,marginTop:8,lineHeight:0.95}}>{c}</div>
</div></div>))}
</div></>);}

function G7_Festival({w,h}){return(<>
<GridBg/><TopLeftLogo top={40} left={40} height={22}/>
<svg style={{position:'absolute',inset:0,opacity:0.15}} viewBox="0 0 1080 1080"><g stroke={C.coral} strokeWidth="1" fill="none">
{Array.from({length:24}).map((_,i)=><circle key={i} cx="540" cy="540" r={30+i*25}/>)}
</g></svg>
<div style={{position:'absolute',inset:0,display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',padding:'0 60px',textAlign:'center'}}>
<Display size={120} color={C.coral} lh={0.9}>Happy Diwali.</Display>
<Body size={16} color={C.bodySoft} style={{marginTop:20}}>From the Sorted team. 🙏</Body>
<div style={{marginTop:30}}><PhotoPlaceholder h={180} w={320} label="Drop team celebration photo"/></div>
</div></>);}

function G8_YearWrap({w,h}){return(<>
<GridBg/><div style={{position:'absolute',inset:0,display:'flex',alignItems:'center',justifyContent:'center',fontFamily:F.display,fontSize:800,color:'rgba(232,38,75,0.08)',letterSpacing:'-20px',lineHeight:1}}>2025</div>
<TopLeftLogo top={40} left={40} height={22}/>
<div style={{position:'absolute',top:60,left:50,right:50,textAlign:'center'}}><Display size={80} color={C.white}>2025 Wrapped.</Display></div>
<div style={{position:'absolute',left:50,right:50,top:200,display:'grid',gridTemplateColumns:'repeat(2,1fr)',gap:16}}>
{[['$40M+','Revenue tracked'],['34','Team members'],['100+','Brands scaled'],['7','New partners']].map(([v,l],i)=>(
<div key={i} style={{background:C.navyLight,border:`1px solid ${C.border}`,borderTop:`3px solid ${C.coral}`,borderRadius:10,padding:22}}>
<div style={{fontFamily:F.display,fontSize:90,color:C.coral,lineHeight:0.9}}>{v}</div>
<Eyebrow color={C.white} size={12} style={{marginTop:8}}>{l}</Eyebrow></div>))}
</div>
<div style={{position:'absolute',left:50,right:50,bottom:50}}><PhotoPlaceholder h={180} label="Drop team year-end photo"/></div>
</>);}

Object.assign(window, {G1_EventAnnounce, G2_EventRecap, G3_Speaking, G4_Kickoff, G5_Award, G6_Office, G7_Festival, G8_YearWrap});
