// Category K — LinkedIn Specific (6)
function K1_LIHeader({w,h}){return(<>
<GridBg/><TopLeftLogo top={30} left={40} height={22}/>
<div style={{position:'absolute',inset:'80px 50px 50px',display:'flex',flexDirection:'column',justifyContent:'center'}}>
<Eyebrow size={12} ls="0.3em">Hook Post</Eyebrow>
<Display size={72} color={C.white} lh={0.95} style={{marginTop:14}}>Klaviyo went from 8% to 44% of revenue in 90 days.</Display>
<Body size={15} color={C.bodySoft} style={{marginTop:14}}>Here's the exact 4-step framework we used 👇</Body>
<Body size={12} color={C.coral} weight={700} style={{marginTop:18,letterSpacing:'0.28em',textTransform:'uppercase'}}>Read 👇</Body>
</div></>);}

function K2_LIDocCover({w,h}){return(<>
<div style={{position:'absolute',left:0,top:0,bottom:0,width:10,background:C.coral}}/>
<GridBg/><TopLeftLogo top={40} left={60} height={22}/>
<div style={{position:'absolute',inset:'100px 50px 50px 60px',display:'flex',flexDirection:'column'}}>
<Eyebrow size={14} ls="0.32em">Sorted Playbook · Vol. 01</Eyebrow>
<Display size={120} color={C.white} lh={0.88} style={{marginTop:30}}>The D2C Klaviyo<br/>Playbook.</Display>
<Body size={16} color={C.bodySoft} style={{marginTop:22}}>7 flows. 30 days. 42% of revenue. A field manual for founders.</Body>
<div style={{marginTop:40}}><PhotoPlaceholder h={280} label="Drop relevant visual"/></div>
<div style={{marginTop:'auto',paddingTop:20,display:'flex',justifyContent:'space-between',alignItems:'center'}}>
<Body size={12} color={C.muted} weight={700} style={{letterSpacing:'0.28em',textTransform:'uppercase'}}>Swipe to read →</Body>
<Mark size={44}/>
</div>
</div></>);}

function K3_LIAnnouncement({w,h}){return(<>
<GridBg/><TopLeftLogo top={40} left={40} height={22}/>
<div style={{position:'absolute',top:40,right:40}}><Pill tone="coralFill" size="sm">Announcement</Pill></div>
<div style={{position:'absolute',inset:'100px 50px 70px',display:'flex',flexDirection:'column',justifyContent:'center'}}>
<Display size={76} color={C.white} lh={0.92}>Sorted is now a certified Klaviyo Gold Partner.</Display>
<Body size={16} color={C.bodySoft} style={{marginTop:18,maxWidth:900}}>
Official partner status. Full API access. Dedicated Klaviyo strategist on every engagement.
</Body>
<Body size={13} color={C.coral} weight={700} style={{marginTop:22,letterSpacing:'0.28em',textTransform:'uppercase'}}>Read the full announcement → sorted.agency/news</Body>
</div></>);}

function K4_LIPoll({w,h}){const r=[['Meta ads',22],['Klaviyo flows',58],['SEO',12],['SMS',8]];return(<>
<GridBg/><TopLeftLogo top={40} left={40} height={22}/>
<div style={{position:'absolute',top:80,left:50,right:50}}>
<Eyebrow>Sorted Poll · 100 D2C Founders</Eyebrow>
<Display size={48} color={C.white} lh={0.95} style={{marginTop:10}}>Where is your next $10K of revenue coming from?</Display>
</div>
<div style={{position:'absolute',left:50,right:50,top:240,display:'flex',flexDirection:'column',gap:10}}>
{r.map(([t,v],i)=>(<div key={i}>
<div style={{display:'flex',justifyContent:'space-between',marginBottom:6}}>
<Body size={13} color={C.white} weight={700}>{t}</Body><Body size={13} color={C.coral} weight={700}>{v}%</Body></div>
<div style={{height:18,background:C.navyLight,borderRadius:4,overflow:'hidden'}}>
<div style={{width:`${v}%`,height:'100%',background:v>40?C.coral:C.muted}}/></div>
</div>))}</div>
<div style={{position:'absolute',bottom:30,left:50,right:50}}>
<Body size={13} color={C.bodySoft}>Klaviyo wins. Again. <span style={{color:C.coral,fontWeight:700}}>Your answer? Comment ↓</span></Body></div>
</>);}

function K5_LIThought({w,h}){return(<>
<GridBg/><div style={{position:'absolute',left:0,top:0,bottom:0,width:4,background:C.coral}}/>
<TopLeftLogo top={40} left={60} height={22}/>
<div style={{position:'absolute',inset:'100px 50px 70px 70px',display:'flex',flexDirection:'column',justifyContent:'center'}}>
<Eyebrow size={12} ls="0.3em">Editorial · Sorted Notes</Eyebrow>
<Body size={18} color={C.bodySoft} lh={1.6} style={{marginTop:18,maxWidth:850}}>
Agencies get addicted to retainers. They sell hours because that's what they can measure. But hours aren't outcomes — and D2C founders don't buy hours, they buy revenue.
</Body>
<Display size={52} color={C.white} lh={1.05} style={{marginTop:30,fontStyle:'italic'}}>"If you can't measure it, we can't charge for it."</Display>
<div style={{marginTop:26,display:'flex',alignItems:'center',gap:14}}>
<AvatarPlaceholder size={48} label="DP"/>
<div>
<div style={{fontFamily:F.body,fontSize:13,fontWeight:700,color:C.white}}>Dhiraj Palekar</div>
<div style={{fontFamily:F.body,fontSize:11,color:C.muted}}>Founder · Sorted</div>
</div></div></div></>);}

function K6_LITeamAnnounce({w,h}){return(<>
<GridBg/><TopLeftLogo top={40} left={40} height={22}/>
<div style={{position:'absolute',top:40,right:40}}><Pill tone="coralFill" size="sm">We're Growing</Pill></div>
<div style={{position:'absolute',inset:'100px 50px 50px',display:'grid',gridTemplateColumns:'1fr 1.3fr',gap:30}}>
<PhotoPlaceholder h="100%" label="Drop new hire headshot"/>
<div style={{display:'flex',flexDirection:'column',justifyContent:'center'}}>
<Eyebrow>New Squad Member</Eyebrow>
<Display size={56} color={C.white} lh={0.9} style={{marginTop:12}}>Meet [Name].</Display>
<Body size={15} color={C.coral} weight={700} style={{marginTop:10,letterSpacing:'0.2em',textTransform:'uppercase'}}>Head of Performance · Mumbai</Body>
<Body size={14} color={C.bodySoft} style={{marginTop:18,lineHeight:1.55}}>
Joins from [Previous Co]. Will lead our Meta + Google pod across 40+ D2C brands. Loud opinions on creative testing and budget splits — just how we like it.
</Body>
<Body size={12} color={C.coral} weight={700} style={{marginTop:20,letterSpacing:'0.28em',textTransform:'uppercase'}}>Follow [Name] on LinkedIn →</Body>
</div></div></>);}

Object.assign(window, {K1_LIHeader, K2_LIDocCover, K3_LIAnnouncement, K4_LIPoll, K5_LIThought, K6_LITeamAnnounce});
