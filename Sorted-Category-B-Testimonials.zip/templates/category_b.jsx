// ============================================================
// Category B — Testimonials (8 templates)
// ============================================================

const TESTIMONIALS = {
  brandon: {
    quote: "They're incredibly ethical and go above and beyond to help you scale. One of the rare agencies that actually cares about your outcome.",
    name: "Brandon Gil",
    role: "President, Gil Ventures LLC",
  },
  avni: {
    quote: "Revenue tripled in 6 months. They rebuilt our entire growth engine from the ground up.",
    name: "Avni Mehra",
    role: "Founder, Leafmark Beauty",
  },
  rahul: {
    quote: "Klaviyo went from 8% to 44% of revenue in a single quarter. I've never seen a team move this fast.",
    name: "Rahul Sen",
    role: "CMO, URC Beverages",
  },
  mira: {
    quote: "The Peshwa Swarm reports are sharper than my internal team's. We cancelled two tools after onboarding Sorted.",
    name: "Mira Kapoor",
    role: "Co-founder, Homestead Collective",
  },
  dev: {
    quote: "They don't sell hours. They sell outcomes. 4.8× ROAS sustained for 9 months.",
    name: "Dev Iyer",
    role: "Founder, Rev Scale",
  },
  sara: {
    quote: "Sorted caught a $40K/month attribution error Meta missed. That's the kind of detail you pay for.",
    name: "Sara Qureshi",
    role: "Head of Growth, EZ Melts",
  },
};

// ---------- B1 · Brandon Gil Quote ----------
function B1_BrandonQuote({ w, h }) {
  const isSquare = w === h;
  const pad = isSquare ? 60 : 48;
  const t = TESTIMONIALS.brandon;
  return (
    <>
      <GridBg />
      <TopLeftLogo top={pad} left={pad} height={22} />
      <div style={{ position: 'absolute', top: pad, right: pad }}>
        <Pill tone="neutral" size="sm">Client Testimonial</Pill>
      </div>

      {/* big coral quote mark */}
      <div style={{
        position: 'absolute', top: pad + (isSquare ? 70 : 50), left: pad,
        fontFamily: F.display, fontSize: isSquare ? 240 : 180,
        color: C.coral, lineHeight: 0.7, opacity: 0.9,
      }}>"</div>

      <div style={{
        position: 'absolute',
        top: pad + (isSquare ? 220 : 150),
        left: pad, right: pad,
      }}>
        <Stars size={isSquare ? 22 : 18} />
        <Body
          size={isSquare ? 28 : 20}
          color={C.white}
          lh={1.35}
          style={{
            fontStyle: 'italic', fontWeight: 500, marginTop: 20,
            maxWidth: isSquare ? 900 : 900,
          }}
        >"{t.quote}"</Body>
      </div>

      {/* divider + attribution */}
      <div style={{
        position: 'absolute', left: pad, right: pad, bottom: pad,
      }}>
        <div style={{ height: 1, background: C.border, marginBottom: 22 }} />
        <div style={{ display: 'flex', alignItems: 'center', gap: 18 }}>
          <AvatarPlaceholder size={64} label="Drop headshot" />
          <div style={{ flex: 1 }}>
            <div style={{
              fontFamily: F.display, fontSize: 26, color: C.white,
              letterSpacing: '0.5px', lineHeight: 1,
            }}>{t.name}</div>
            <Body size={13} color={C.muted} style={{ marginTop: 4 }}>{t.role}</Body>
          </div>
          <Mark size={40} />
        </div>
      </div>
    </>
  );
}

// ---------- B2 · Large Full-Bleed Quote ----------
function B2_FullBleedQuote({ w, h }) {
  const isSquare = w === h;
  const pad = isSquare ? 50 : 40;
  const t = TESTIMONIALS.avni;
  return (
    <>
      {/* inset card */}
      <div style={{
        position: 'absolute', inset: pad,
        background: C.navyLight,
        border: `1px solid ${C.border}`,
        borderRadius: 16,
        padding: isSquare ? 60 : 48,
        display: 'flex', flexDirection: 'column',
      }}>
        <div style={{
          fontFamily: F.display, fontSize: isSquare ? 220 : 160,
          color: C.coral, lineHeight: 0.7, marginBottom: 10,
        }}>"</div>

        <div style={{
          fontFamily: F.body, fontStyle: 'italic', fontWeight: 500,
          fontSize: isSquare ? 34 : 24,
          color: C.white, lineHeight: 1.35,
          textWrap: 'balance',
        }}>{t.quote}</div>

        <div style={{
          marginTop: 'auto', paddingTop: 32,
          display: 'flex', alignItems: 'center', gap: 18,
        }}>
          <AvatarPlaceholder size={80} label="Drop headshot" />
          <div style={{ flex: 1 }}>
            <div style={{ fontFamily: F.display, fontSize: 30, color: C.white, letterSpacing: '0.5px' }}>
              {t.name}
            </div>
            <Body size={14} color={C.muted} style={{ marginTop: 4 }}>{t.role}</Body>
          </div>
          <Logo height={22} />
        </div>
      </div>
    </>
  );
}

// ---------- B3 · DM Screenshot Style ----------
function B3_DMScreenshot({ w, h }) {
  const isSquare = w === h;
  const pad = isSquare ? 50 : 36;
  const t = TESTIMONIALS.rahul;
  return (
    <>
      <GridBg />
      <div style={{ position: 'absolute', top: pad, left: pad }}>
        <Eyebrow>Real Message · Unedited</Eyebrow>
      </div>
      <TopRightLogo top={pad} right={pad} height={20} />

      {/* LinkedIn-style chat */}
      <div style={{
        position: 'absolute',
        left: pad, right: pad,
        top: pad + 50, bottom: pad + 60,
        background: '#0E1B2E',
        border: `1px solid ${C.border}`,
        borderRadius: 14,
        padding: isSquare ? 28 : 20,
        display: 'flex', flexDirection: 'column', gap: 14,
      }}>
        {/* chat header */}
        <div style={{
          display: 'flex', alignItems: 'center', gap: 12,
          paddingBottom: 14,
          borderBottom: `1px solid ${C.border}`,
        }}>
          <AvatarPlaceholder size={40} label="Avatar" />
          <div style={{ flex: 1 }}>
            <div style={{ fontFamily: F.body, fontWeight: 700, fontSize: 14, color: C.white }}>{t.name}</div>
            <div style={{ fontFamily: F.body, fontSize: 11, color: C.muted }}>active now · LinkedIn</div>
          </div>
          <svg width="16" height="16" viewBox="0 0 24 24" fill={C.muted}>
            <circle cx="5" cy="12" r="2"/><circle cx="12" cy="12" r="2"/><circle cx="19" cy="12" r="2"/>
          </svg>
        </div>

        {/* bubbles */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10, marginTop: 4 }}>
          <div style={{
            alignSelf: 'flex-start',
            maxWidth: '85%',
            background: C.navy,
            border: `1px solid ${C.border}`,
            borderRadius: '14px 14px 14px 4px',
            padding: '14px 18px',
          }}>
            <Body size={isSquare ? 18 : 14} color={C.white} lh={1.45} style={{ fontStyle: 'italic' }}>
              "{t.quote}"
            </Body>
          </div>
          <div style={{
            alignSelf: 'flex-start', display: 'flex', gap: 6, alignItems: 'center',
          }}>
            <Body size={11} color={C.muted}>12:42 PM · via LinkedIn</Body>
            <svg width="12" height="10" viewBox="0 0 18 14" fill="none">
              <path d="M1 7l4 4 12-12M6 7l4 4" stroke={C.coral} strokeWidth="2"/>
            </svg>
          </div>
        </div>
      </div>

      <div style={{
        position: 'absolute', bottom: pad, left: pad, right: pad,
        display: 'flex', justifyContent: 'space-between', alignItems: 'center',
      }}>
        <Body size={11} color={C.muted} weight={700}
              style={{ letterSpacing: '0.26em', textTransform: 'uppercase' }}>
          {t.role}
        </Body>
        <Mark size={32} />
      </div>
    </>
  );
}

// ---------- B4 · 3-Up Grid ----------
function B4_ThreeUp({ w, h }) {
  const isSquare = w === h;
  const pad = 40;
  const picks = [TESTIMONIALS.brandon, TESTIMONIALS.avni, TESTIMONIALS.dev];
  // shorten quotes for card size
  const short = [
    "Incredibly ethical. They actually care about your outcome.",
    "Revenue tripled in 6 months. Whole engine rebuilt.",
    "They sell outcomes, not hours. 4.8× ROAS for 9 months.",
  ];
  return (
    <>
      <GridBg />
      <div style={{
        position: 'absolute', top: pad, left: pad, right: pad,
        display: 'flex', justifyContent: 'space-between', alignItems: 'center',
      }}>
        <div style={{ fontFamily: F.display, fontSize: isSquare ? 56 : 40, color: C.white, letterSpacing: '0.5px' }}>
          What Clients Say.
        </div>
        <Logo height={22} />
      </div>

      <div style={{
        position: 'absolute', left: pad, right: pad,
        top: isSquare ? 150 : 110, bottom: pad,
        display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 18,
      }}>
        {picks.map((t, i) => (
          <div key={i} style={{
            background: C.navyLight,
            borderRadius: 12,
            border: `1px solid ${C.border}`,
            borderTop: `3px solid ${C.coral}`,
            padding: isSquare ? 24 : 18,
            display: 'flex', flexDirection: 'column', gap: 14,
          }}>
            <Stars size={14} />
            <Body size={isSquare ? 15 : 13} color={C.white} lh={1.5}
                  style={{ fontStyle: 'italic', flex: 1 }}>
              "{short[i]}"
            </Body>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, paddingTop: 8, borderTop: `1px solid ${C.border}` }}>
              <AvatarPlaceholder size={36} label="avatar" />
              <div>
                <div style={{ fontFamily: F.body, fontSize: isSquare ? 13 : 11, fontWeight: 700, color: C.white }}>{t.name}</div>
                <div style={{ fontFamily: F.body, fontSize: isSquare ? 11 : 10, color: C.muted }}>{t.role}</div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </>
  );
}

// ---------- B5 · Wall of Love ----------
function B5_WallOfLove({ w, h }) {
  const picks = Object.values(TESTIMONIALS).slice(0, 6);
  const shortForms = [
    "They actually care about your outcome.",
    "Revenue tripled in 6 months.",
    "Klaviyo went from 8% to 44% of revenue.",
    "Reports sharper than my internal team's.",
    "4.8× ROAS sustained for 9 months.",
    "Caught a $40K/mo attribution error.",
  ];
  return (
    <>
      <GridBg />
      <TopLeftLogo top={44} left={44} height={22} />

      <div style={{ position: 'absolute', top: 44, right: 44, textAlign: 'right' }}>
        <Eyebrow size={12} ls="0.28em">100+ D2C brands trust Sorted</Eyebrow>
      </div>

      <div style={{ position: 'absolute', top: 110, left: 44, right: 44, textAlign: 'center' }}>
        <Display size={84} color={C.white} lh={0.92}>The Wall of Love.</Display>
      </div>

      <div style={{
        position: 'absolute', left: 44, right: 44, top: 240, bottom: 60,
        display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gridTemplateRows: 'repeat(3, 1fr)', gap: 14,
      }}>
        {picks.map((t, i) => (
          <div key={i} style={{
            background: i % 2 ? C.navyLight : 'rgba(255,255,255,0.02)',
            border: `1px solid ${C.border}`,
            borderLeft: `3px solid ${C.coral}`,
            borderRadius: 8,
            padding: '16px 20px',
            display: 'flex', flexDirection: 'column', gap: 8,
          }}>
            <Body size={15} color={C.white} lh={1.45} style={{ fontStyle: 'italic' }}>
              "{shortForms[i]}"
            </Body>
            <Body size={11} color={C.muted} weight={700}
                  style={{ letterSpacing: '0.18em', textTransform: 'uppercase' }}>
              {t.name} · {t.role.split(',')[1]?.trim() || t.role}
            </Body>
          </div>
        ))}
      </div>
    </>
  );
}

// ---------- B6 · Client Logo Proof Bar ----------
function B6_LogoProofBar({ w, h }) {
  const isSquare = w === h;
  const logos = [
    'URC', 'MIT Sloan', 'WHO', 'Rev Scale', 'Surge', 'EZ Melts',
    'Homestead', 'TFC', 'Teplo', 'Free Range', 'Sent', 'Explosive Whey',
  ];
  return (
    <>
      <GridBg />
      <TopLeftLogo top={40} left={40} height={20} />

      <div style={{
        position: 'absolute', inset: 0,
        display: 'flex', flexDirection: 'column',
        alignItems: 'center', justifyContent: 'center',
        padding: isSquare ? '80px 60px' : '60px 60px',
      }}>
        <Eyebrow size={13} ls="0.32em" color={C.coral}>Trusted By</Eyebrow>
        <Display size={isSquare ? 100 : 74} color={C.white} lh={0.9} style={{ marginTop: 14, textAlign: 'center' }}>
          100+ D2C brands.
        </Display>

        <div style={{
          marginTop: isSquare ? 60 : 40, width: '100%', maxWidth: isSquare ? 900 : 1000,
          display: 'grid',
          gridTemplateColumns: isSquare ? 'repeat(4, 1fr)' : 'repeat(6, 1fr)',
          gap: isSquare ? 18 : 12,
        }}>
          {logos.slice(0, isSquare ? 12 : 12).map((n, i) => (
            <div key={i} style={{
              height: isSquare ? 60 : 50,
              background: 'rgba(255,255,255,0.04)',
              border: `1px dashed ${C.border}`,
              borderRadius: 6,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontFamily: F.display,
              fontSize: isSquare ? 18 : 14,
              color: 'rgba(255,255,255,0.55)',
              letterSpacing: '1px',
            }}>{n}</div>
          ))}
        </div>
      </div>
    </>
  );
}

// ---------- B7 · Video Testimonial ----------
function B7_VideoTestimonial({ w, h }) {
  const isSquare = w === h;
  const t = TESTIMONIALS.mira;
  return (
    <>
      {/* photo fill */}
      <div style={{ position: 'absolute', inset: 0 }}>
        <PhotoPlaceholder w="100%" h="100%" label="Drop client video thumbnail" rounded={0} />
      </div>

      {/* dark gradient overlay */}
      <div style={{
        position: 'absolute', inset: 0,
        background: 'linear-gradient(180deg, rgba(9,24,43,0.45) 0%, rgba(9,24,43,0.05) 35%, rgba(9,24,43,0.9) 85%)',
      }} />

      <TopLeftLogo top={32} left={32} height={22} />
      <div style={{ position: 'absolute', top: 32, right: 32 }}>
        <Pill tone="coralFill" size="sm">Client Story</Pill>
      </div>

      {/* play button */}
      <div style={{
        position: 'absolute', left: '50%', top: '44%',
        transform: 'translate(-50%, -50%)',
        width: isSquare ? 120 : 90, height: isSquare ? 120 : 90,
        borderRadius: '50%', background: C.coral,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        boxShadow: '0 20px 50px -10px rgba(232,38,75,0.55)',
      }}>
        <svg width={isSquare ? 40 : 30} height={isSquare ? 46 : 34} viewBox="0 0 24 28" fill="#fff">
          <path d="M0 0v28l24-14z"/>
        </svg>
      </div>

      {/* bottom strip */}
      <div style={{
        position: 'absolute', bottom: 32, left: 32, right: 32,
        display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end',
      }}>
        <div>
          <div style={{
            fontFamily: F.display, fontSize: isSquare ? 36 : 28, color: C.white,
            letterSpacing: '0.5px',
          }}>{t.name}</div>
          <Body size={13} color={C.bodySoft} style={{ marginTop: 2 }}>{t.role}</Body>
        </div>
        <Body size={12} color={C.coral} weight={700}
              style={{ letterSpacing: '0.28em', textTransform: 'uppercase' }}>
          Watch their story →
        </Body>
      </div>
    </>
  );
}

// ---------- B8 · Partner Logo Bar ----------
function B8_PartnerBar({ w, h }) {
  const partners = ['Meta', 'Google', 'Shopify', 'Klaviyo', 'AWS', 'Salesforce', 'Razorpay', 'Odoo'];
  return (
    <>
      <GridBg />
      <TopLeftLogo top={40} left={40} height={22} />

      <div style={{
        position: 'absolute', inset: 0,
        display: 'flex', flexDirection: 'column',
        alignItems: 'center', justifyContent: 'center',
        padding: '80px 60px',
      }}>
        <Eyebrow size={12} ls="0.32em">Certified Partners</Eyebrow>
        <Display size={72} color={C.white} lh={0.9} style={{ marginTop: 12, textAlign: 'center' }}>
          The full D2C stack.
        </Display>
        <Body size={14} color={C.bodySoft} style={{ marginTop: 12, textAlign: 'center', maxWidth: 600 }}>
          Official agency partners across the full D2C stack.
        </Body>

        <div style={{
          marginTop: 40, width: '100%', maxWidth: 1000,
          display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 14,
        }}>
          {partners.map((n, i) => (
            <div key={i} style={{
              height: 60,
              background: 'rgba(255,255,255,0.04)',
              border: `1px solid ${C.border}`,
              borderRadius: 6,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontFamily: F.display,
              fontSize: 18,
              color: 'rgba(255,255,255,0.6)',
              letterSpacing: '1px',
            }}>{n}</div>
          ))}
        </div>
      </div>
      <BottomRightMark bottom={32} right={40} size={36} />
    </>
  );
}

Object.assign(window, {
  TESTIMONIALS,
  B1_BrandonQuote, B2_FullBleedQuote, B3_DMScreenshot, B4_ThreeUp,
  B5_WallOfLove, B6_LogoProofBar, B7_VideoTestimonial, B8_PartnerBar,
});
