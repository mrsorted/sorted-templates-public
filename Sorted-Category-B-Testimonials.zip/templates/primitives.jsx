// ============================================================
// Template Library — shared primitives
// ============================================================

const C = {
  navy: '#09182B', navyLight: '#0F2240', navyMid: '#132B4F',
  coral: '#E8264B', coralGlow: '#FF3D5E',
  white: '#F8F7F4', cream: '#EDE9E0',
  muted: '#8A94A6', bodySoft: '#b8c4d8',
  border: 'rgba(255,255,255,0.09)',
  borderStrong: 'rgba(255,255,255,0.16)',
  coralSoft: 'rgba(232,38,75,0.08)',
};

const F = {
  display: "'Bebas Neue', sans-serif",
  body:    "'DM Sans', system-ui, sans-serif",
};

// ---------- Artboard ----------
// A labeled, fixed-size frame. All templates render inside one.
function Artboard({ code, platform, w, h, children, bg = C.navy, label }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
      <div style={{
        fontFamily: F.body, fontSize: 11, fontWeight: 700,
        letterSpacing: '0.22em', textTransform: 'uppercase', color: C.muted,
        display: 'flex', gap: 10, alignItems: 'center',
      }}>
        <span style={{ color: C.coral }}>{code}</span>
        <span style={{ opacity: 0.4 }}>·</span>
        <span>{platform}</span>
        <span style={{ opacity: 0.4 }}>·</span>
        <span style={{ color: C.bodySoft }}>{w}×{h}</span>
        {label && <>
          <span style={{ opacity: 0.4 }}>·</span>
          <span style={{ textTransform: 'none', letterSpacing: 0, color: C.bodySoft, fontWeight: 400 }}>{label}</span>
        </>}
      </div>
      <div style={{
        width: w, height: h, background: bg,
        position: 'relative', overflow: 'hidden',
        borderRadius: 6,
        outline: `1px solid ${C.border}`,
        outlineOffset: -1,
      }}>
        {children}
      </div>
    </div>
  );
}

// ---------- Grid overlay (60px, 2% opacity) ----------
function GridBg({ opacity = 1 }) {
  return (
    <div style={{
      position: 'absolute', inset: 0,
      backgroundImage: `linear-gradient(to right, rgba(255,255,255,0.025) 1px, transparent 1px),
                        linear-gradient(to bottom, rgba(255,255,255,0.025) 1px, transparent 1px)`,
      backgroundSize: '60px 60px',
      opacity, pointerEvents: 'none',
    }} />
  );
}

// ---------- Coral radial glow ----------
function CoralGlow({ size = 700, top = '-20%', right = '-15%', bottom, left, op = 0.45 }) {
  return (
    <div style={{
      position: 'absolute', top, right, bottom, left,
      width: size, height: size,
      background: `radial-gradient(circle, rgba(232,38,75,${op}), transparent 65%)`,
      filter: 'blur(40px)', pointerEvents: 'none',
    }} />
  );
}

// ---------- Logo / Mark ----------
function Logo({ height = 30, style }) {
  return <img src="assets/sorted-logo.png" alt="Sorted" style={{ height, display: 'block', ...style }} />;
}
function Mark({ size = 56, style }) {
  return <img src="assets/sorted-mark.png" alt="" style={{ width: size, height: size, display: 'block', ...style }} />;
}

// ---------- Display text ----------
function Display({ children, size = 120, lh = 0.95, color = C.white, ls = '1px', style, nowrap }) {
  return (
    <div style={{
      fontFamily: F.display, fontSize: size, lineHeight: lh,
      letterSpacing: ls, textTransform: 'uppercase', color,
      whiteSpace: nowrap ? 'nowrap' : 'normal',
      ...style,
    }}>{children}</div>
  );
}

// Multi-line version (splits on \n; each line nowrap-safe)
function DisplayLines({ lines, size = 120, lh = 0.95, color = C.white, ls = '1px', style }) {
  return (
    <div style={{
      fontFamily: F.display, fontSize: size, lineHeight: lh,
      letterSpacing: ls, textTransform: 'uppercase', color, ...style,
    }}>
      {lines.map((l, i) => <div key={i} style={{ whiteSpace: 'nowrap' }}>{l}</div>)}
    </div>
  );
}

// ---------- Body text ----------
function Body({ children, size = 16, weight = 400, color = C.bodySoft, lh = 1.55, style }) {
  return (
    <div style={{
      fontFamily: F.body, fontSize: size, fontWeight: weight,
      lineHeight: lh, color, ...style,
    }}>{children}</div>
  );
}

// ---------- Eyebrow / label ----------
function Eyebrow({ children, color = C.coral, size = 12, ls = '0.22em', style }) {
  return (
    <div style={{
      fontFamily: F.body, fontSize: size, fontWeight: 700,
      letterSpacing: ls, textTransform: 'uppercase', color, ...style,
    }}>{children}</div>
  );
}

// ---------- Pill (tag/badge) ----------
function Pill({ children, tone = 'coral', size = 'md' }) {
  const sizes = { sm: [10, '4px 10px'], md: [11, '6px 12px'], lg: [13, '8px 16px'] };
  const tones = {
    coral:   { bg: 'rgba(232,38,75,0.12)', bd: 'rgba(232,38,75,0.35)', fg: C.coral },
    coralFill: { bg: C.coral, bd: C.coral, fg: '#fff' },
    neutral: { bg: 'rgba(255,255,255,0.05)', bd: C.border, fg: C.muted },
    white:   { bg: 'rgba(255,255,255,0.06)', bd: C.borderStrong, fg: C.white },
  };
  const [fs, pad] = sizes[size];
  const t = tones[tone];
  return (
    <span style={{
      display: 'inline-block',
      background: t.bg, border: `1px solid ${t.bd}`, color: t.fg,
      fontFamily: F.body, fontSize: fs, fontWeight: 700,
      letterSpacing: '0.18em', textTransform: 'uppercase',
      padding: pad, borderRadius: 999,
    }}>{children}</span>
  );
}

// ---------- CTA button ----------
function CtaButton({ children, size = 'md', style }) {
  const sizes = { sm: [12, '10px 18px'], md: [14, '14px 24px'], lg: [16, '18px 32px'] };
  const [fs, pad] = sizes[size];
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: 10,
      background: C.coral, color: '#fff',
      padding: pad, borderRadius: 6,
      fontFamily: F.body, fontSize: fs, fontWeight: 700,
      letterSpacing: '0.14em', textTransform: 'uppercase',
      boxShadow: '0 12px 30px -8px rgba(232,38,75,0.5)',
      ...style,
    }}>
      {children}
      <svg width="18" height="12" viewBox="0 0 22 10" fill="none">
        <path d="M1 5h20M16 1l5 4-5 4" stroke="#fff" strokeWidth="1.8"/>
      </svg>
    </span>
  );
}

// ---------- Photo placeholder ----------
function PhotoPlaceholder({ w = '100%', h = 200, label = 'Drop photo here', rounded = 12, style }) {
  return (
    <div style={{
      width: w, height: h, background: C.navyLight,
      border: `1.5px dashed ${C.coral}`, borderRadius: rounded,
      display: 'flex', flexDirection: 'column', alignItems: 'center',
      justifyContent: 'center', gap: 12,
      position: 'relative', overflow: 'hidden',
      ...style,
    }}>
      <Mark size={40} style={{ opacity: 0.8 }} />
      <div style={{
        fontFamily: F.body, fontStyle: 'italic', fontSize: 13,
        color: C.muted, letterSpacing: '0.04em',
      }}>{label}</div>
    </div>
  );
}

// ---------- Avatar placeholder (circle) ----------
function AvatarPlaceholder({ size = 80, label = 'Drop headshot' }) {
  return (
    <div style={{
      width: size, height: size, borderRadius: '50%',
      background: C.navyLight,
      border: `1.5px dashed ${C.coral}`,
      display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
      fontFamily: F.body, fontSize: Math.max(8, size/12), fontStyle: 'italic',
      color: C.muted, textAlign: 'center', padding: 4, lineHeight: 1.2,
    }}>{label}</div>
  );
}

// ---------- Stat card (navy-light + coral top bar) ----------
function StatCard({ value, label, w = 'auto', h = 'auto', style }) {
  return (
    <div style={{
      background: C.navyLight,
      border: `1px solid ${C.border}`,
      borderRadius: 10,
      boxShadow: 'inset 0 1px 0 rgba(255,255,255,0.04)',
      padding: '20px 22px 18px',
      borderTop: `3px solid ${C.coral}`,
      width: w, height: h, ...style,
    }}>
      <div style={{
        fontFamily: F.display, fontSize: 52, lineHeight: 0.95,
        color: C.coral, letterSpacing: '0.5px',
      }}>{value}</div>
      <div style={{
        marginTop: 8, fontFamily: F.body, fontSize: 12, fontWeight: 600,
        letterSpacing: '0.12em', textTransform: 'uppercase', color: C.bodySoft,
      }}>{label}</div>
    </div>
  );
}

// ---------- Stars ----------
function Stars({ size = 16, color = C.coral, count = 5 }) {
  return (
    <div style={{ display: 'inline-flex', gap: 2 }}>
      {Array.from({ length: count }).map((_, i) => (
        <svg key={i} width={size} height={size} viewBox="0 0 24 24" fill={color}>
          <path d="M12 2l2.9 6.9L22 10l-5.5 4.8L18 22l-6-3.5L6 22l1.5-7.2L2 10l7.1-1.1L12 2z"/>
        </svg>
      ))}
    </div>
  );
}

// ---------- Corner logo + mark helpers (for artboard chrome) ----------
function TopLeftLogo({ top = 40, left = 40, height = 24 }) {
  return <Logo height={height} style={{ position: 'absolute', top, left }} />;
}
function TopRightLogo({ top = 40, right = 40, height = 24 }) {
  return <Logo height={height} style={{ position: 'absolute', top, right }} />;
}
function BottomRightMark({ bottom = 32, right = 32, size = 44 }) {
  return <Mark size={size} style={{ position: 'absolute', bottom, right }} />;
}
function BottomLeftUrl({ bottom = 34, left = 40, fontSize = 12 }) {
  return (
    <div style={{
      position: 'absolute', bottom, left,
      fontFamily: F.body, fontSize, fontWeight: 700, color: C.bodySoft,
      letterSpacing: '0.22em', textTransform: 'uppercase',
    }}>sorted.agency</div>
  );
}

// ---------- Category page wrapper ----------
function CategoryPage({ id, title, subtitle, children }) {
  return (
    <section id={id} data-screen-label={id} style={{
      padding: '48px 40px 64px', borderTop: `1px solid ${C.border}`,
    }}>
      <div style={{ maxWidth: 1400, margin: '0 auto' }}>
        <div style={{ display: 'flex', alignItems: 'baseline', gap: 16, marginBottom: 6 }}>
          <div style={{
            fontFamily: F.display, fontSize: 44, color: C.white,
            letterSpacing: '1px', lineHeight: 1,
          }}>{title}</div>
          <div style={{
            fontFamily: F.body, fontSize: 12, fontWeight: 700,
            letterSpacing: '0.22em', textTransform: 'uppercase', color: C.coral,
          }}>Category {id}</div>
        </div>
        {subtitle && (
          <div style={{
            fontFamily: F.body, fontSize: 15, color: C.bodySoft, marginBottom: 40,
            maxWidth: 820,
          }}>{subtitle}</div>
        )}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 64 }}>
          {children}
        </div>
      </div>
    </section>
  );
}

// ---------- Template group (one template, multiple sizes) ----------
function TemplateGroup({ code, name, note, children }) {
  return (
    <div>
      <div style={{
        display: 'flex', alignItems: 'baseline', gap: 16, marginBottom: 18,
        paddingBottom: 10, borderBottom: `1px solid ${C.border}`,
      }}>
        <div style={{
          fontFamily: F.display, fontSize: 28, color: C.coral,
          letterSpacing: '1px', lineHeight: 1,
        }}>{code}</div>
        <div style={{
          fontFamily: F.body, fontSize: 17, fontWeight: 600, color: C.white,
        }}>{name}</div>
        {note && <div style={{
          fontFamily: F.body, fontSize: 13, color: C.muted, fontStyle: 'italic',
        }}>{note}</div>}
      </div>
      <div style={{ display: 'flex', gap: 32, flexWrap: 'wrap', alignItems: 'flex-start' }}>
        {children}
      </div>
    </div>
  );
}

Object.assign(window, {
  C, F, Artboard, GridBg, CoralGlow, Logo, Mark,
  Display, DisplayLines, Body, Eyebrow, Pill, CtaButton,
  PhotoPlaceholder, AvatarPlaceholder, StatCard, Stars,
  TopLeftLogo, TopRightLogo, BottomRightMark, BottomLeftUrl,
  CategoryPage, TemplateGroup,
});
