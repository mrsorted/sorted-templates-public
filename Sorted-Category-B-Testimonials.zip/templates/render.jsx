// Sizes used across templates
const SIZES = {
  IG:     { w: 1080, h: 1080, label: 'IG 1:1' },
  TW:     { w: 1200, h: 675,  label: 'TW 16:9' },
  LI:     { w: 1200, h: 627,  label: 'LI 1.91:1' },
  STORY:  { w: 1080, h: 1920, label: 'IG Story 9:16' },
  LIDOC:  { w: 1080, h: 1350, label: 'LI Doc 4:5' },
};

// Render a template across multiple sizes
function RenderSizes({ code, name, note, sizes, Component }) {
  return (
    <TemplateGroup code={code} name={name} note={note}>
      {sizes.map(sz => {
        const { w, h, label } = SIZES[sz];
        return (
          <Artboard key={sz} code={code} platform={sz} w={w} h={h} label={label}>
            <Component w={w} h={h} />
          </Artboard>
        );
      })}
    </TemplateGroup>
  );
}

function CategoryB() {
  return (
    <CategoryPage
      id="B"
      title="Testimonials"
      subtitle="Social proof in every format — pull quotes, DM screenshots, 3-up grids, logo bars. Each layout has dashed avatar placeholders for real headshots and keeps coral as accent-only."
    >
      <RenderSizes code="B1" name="Brandon Gil Quote"
        sizes={['IG','TW','LI']} Component={B1_BrandonQuote} />
      <RenderSizes code="B2" name="Large Full-Bleed Quote"
        sizes={['IG','LI']} Component={B2_FullBleedQuote} />
      <RenderSizes code="B3" name="DM Screenshot Style"
        sizes={['LI','IG']} Component={B3_DMScreenshot} />
      <RenderSizes code="B4" name="3-Up Grid"
        sizes={['LI','TW']} Component={B4_ThreeUp} />
      <RenderSizes code="B5" name="Wall of Love"
        sizes={['IG']} Component={B5_WallOfLove} />
      <RenderSizes code="B6" name="Client Logo Proof Bar"
        sizes={['TW','LI','IG']} Component={B6_LogoProofBar} />
      <RenderSizes code="B7" name="Video Testimonial"
        sizes={['IG','LI']} Component={B7_VideoTestimonial} />
      <RenderSizes code="B8" name="Partner Logo Bar"
        sizes={['TW','LI']} Component={B8_PartnerBar} />
    </CategoryPage>
  );
}

function CategoryD() {
  return (
    <CategoryPage id="D" title="Services"
      subtitle="What we actually do, laid out for founders to scan. Performance, email, AI, dev, brand, strategy.">
      <RenderSizes code="D1" name="Performance Marketing" sizes={['IG','LI']} Component={D1_PerfMarketing} />
      <RenderSizes code="D2" name="Email & Retention" sizes={['IG','LI']} Component={D2_EmailRetention} />
      <RenderSizes code="D3" name="Peshwa Swarm AI" sizes={['IG','LI']} Component={D3_PeshwaService} />
      <RenderSizes code="D4" name="Web & App Dev" sizes={['IG','TW','LI']} Component={D4_WebApp} />
      <RenderSizes code="D5" name="Brand & Creative" sizes={['IG']} Component={D5_BrandCreative} />
      <RenderSizes code="D6" name="Strategy & Consulting" sizes={['LI','TW']} Component={D6_Strategy} />
      <RenderSizes code="D7" name="Full-Stack Services Grid" sizes={['IG','LI']} Component={D7_ServicesGrid} />
      <RenderSizes code="D8" name="White-Label for Agencies" sizes={['LI','TW']} Component={D8_WhiteLabel} />
      <RenderSizes code="D9" name="Email Flow Deep Dive" sizes={['IG']} Component={D9_EmailFlows} />
      <RenderSizes code="D10" name="Meta Ads Deep Dive" sizes={['IG','TW']} Component={D10_MetaAds} />
    </CategoryPage>
  );
}

function CategoryC() {
  return (
    <CategoryPage
      id="C"
      title="Stats & Numbers"
      subtitle="Hero numbers, tickers, dashboards, comparison tables. Big Bebas Neue digits in coral against navy — the Sorted calling card."
    >
      <RenderSizes code="C1" name="4-Stat Grid" sizes={['IG','TW','LI']} Component={C1_FourStatGrid} />
      <RenderSizes code="C2" name="Single Hero Stat" sizes={['IG','STORY']} Component={C2_SingleHero} />
      <RenderSizes code="C3" name="Revenue Counter" sizes={['IG','TW']} Component={C3_RevenueCounter} />
      <RenderSizes code="C4" name="Ticker Strip" sizes={['TW','LI']} Component={C4_TickerStrip} />
      <RenderSizes code="C5" name="Speed Stat" sizes={['IG','TW']} Component={C5_SpeedStat} />
      <RenderSizes code="C6" name="AI Peshwa Swarm" sizes={['IG','LI']} Component={C6_PeshwaSwarm} />
      <RenderSizes code="C7" name="Cost Reduction" sizes={['TW','LI']} Component={C7_CostReduction} />
      <RenderSizes code="C8" name="Agencies vs Sorted" sizes={['LI','IG']} Component={C8_VsTable} />
      <RenderSizes code="C9" name="Dashboard Screenshot" sizes={['IG','LI','TW']} Component={C9_Dashboard} />
      <C10_AllFrames />
    </CategoryPage>
  );
}

function CategoryA() {
  return (
    <CategoryPage
      id="A"
      title="Case Studies"
      subtitle="Proof. Real numbers from real client accounts. Each template is ready for you to drop a dashboard screenshot or client creative in the dashed placeholder."
    >
      <RenderSizes code="A1" name="Case Study Full Stats"
        sizes={['IG','TW','LI']} Component={A1_CaseStudyFullStats} />
      <RenderSizes code="A2" name="Revenue Hero Stat"
        sizes={['IG','LI']} Component={A2_RevenueHero} />
      <RenderSizes code="A3" name="ROAS Win"
        sizes={['IG','TW','LI']} Component={A3_ROASWin} />
      <RenderSizes code="A4" name="Before / After Split"
        sizes={['IG','LI']} Component={A4_BeforeAfter} />
      <RenderSizes code="A5" name="Growth % Hero"
        sizes={['IG','LI']} Component={A5_GrowthHero} />
      <RenderSizes code="A6" name="Shopify Win"
        sizes={['IG','TW','LI']} Component={A6_ShopifyWin} />
      <RenderSizes code="A7" name="With Client Photo"
        sizes={['LI','IG']} Component={A7_WithClientPhoto} />
      <RenderSizes code="A8" name="Screenshot Proof"
        sizes={['IG','TW','LI']} Component={A8_ScreenshotProof} />
      <RenderSizes code="A9" name="Carousel Cover" note="Slide 01 / 05"
        sizes={['IG']} Component={A9_CarouselCover} />
      <RenderSizes code="A10" name="Carousel — The Problem" note="Slide 02 / 05"
        sizes={['IG']} Component={A10_CarouselProblem} />
      <RenderSizes code="A11" name="Carousel — What We Did" note="Slide 03 / 05"
        sizes={['IG']} Component={A11_CarouselWhatWeDid} />
      <RenderSizes code="A12" name="Carousel — The Result" note="Slide 05 / 05"
        sizes={['IG']} Component={A12_CarouselResult} />
    </CategoryPage>
  );
}

function CategoryE() {
  return (
    <CategoryPage id="E" title="Thought Leadership"
      subtitle="Hot takes, myths-busted, founder quotes, how-tos. Written to stop the scroll and start a comment thread.">
      <RenderSizes code="E1" name="Did You Know" sizes={['IG','TW']} Component={E1_DidYouKnow} />
      <RenderSizes code="E2" name="Hot Take" sizes={['IG','LI']} Component={E2_HotTake} />
      <RenderSizes code="E3" name="Myth vs Reality" sizes={['IG','LI']} Component={E3_MythReality} />
      <RenderSizes code="E4" name="Three Step Framework" sizes={['IG','LI']} Component={E4_ThreeStep} />
      <RenderSizes code="E5" name="Founder Quote" sizes={['IG','LI']} Component={E5_FounderQuote} />
      <RenderSizes code="E6" name="Trend Alert" sizes={['IG','TW']} Component={E6_TrendAlert} />
      <RenderSizes code="E7" name="Industry Stat" sizes={['TW','LI']} Component={E7_IndustryStat} />
      <RenderSizes code="E8" name="This You?" sizes={['IG','LI']} Component={E8_ThisYou} />
      <RenderSizes code="E9" name="Definition" sizes={['IG','TW']} Component={E9_Definition} />
      <RenderSizes code="E10" name="How-To 4 Steps" sizes={['IG']} Component={E10_HowTo4Steps} />
    </CategoryPage>
  );
}

function CategoryF() {
  return (
    <CategoryPage id="F" title="Team & Culture"
      subtitle="Welcomes, spotlights, anniversaries, hiring, team wins. Human side of Sorted.">
      <RenderSizes code="F1" name="Welcome New Hire" sizes={['IG','LI']} Component={F1_Welcome} />
      <RenderSizes code="F2" name="Employee Spotlight" sizes={['IG','LI']} Component={F2_Spotlight} />
      <RenderSizes code="F3" name="Work Anniversary" sizes={['IG','LI']} Component={F3_Anniversary} />
      <RenderSizes code="F4" name="We're Hiring" sizes={['IG','LI']} Component={F4_Hiring} />
      <RenderSizes code="F5" name="Team Outing" sizes={['IG','LI']} Component={F5_TeamOuting} />
      <RenderSizes code="F6" name="Headcount Milestone" sizes={['IG','LI']} Component={F6_Headcount} />
      <RenderSizes code="F7" name="Behind the Scenes Grid" sizes={['IG']} Component={F7_BehindTheScenes} />
      <RenderSizes code="F8" name="Work Hard Play Hard" sizes={['IG','LI']} Component={F8_Play} />
      <RenderSizes code="F9" name="Team Win" sizes={['IG','LI']} Component={F9_TeamWin} />
      <RenderSizes code="F10" name="Our Values" sizes={['IG','LI']} Component={F10_Values} />
    </CategoryPage>
  );
}

function CategoryG() {
  return (
    <CategoryPage id="G" title="Events & Occasions"
      subtitle="Event announcements, recaps, speaking, kickoffs, awards, festivals, year wraps.">
      <RenderSizes code="G1" name="Event Announcement" sizes={['IG','LI']} Component={G1_EventAnnounce} />
      <RenderSizes code="G2" name="Event Recap" sizes={['IG','LI']} Component={G2_EventRecap} />
      <RenderSizes code="G3" name="Speaking / Stage" sizes={['IG','LI']} Component={G3_Speaking} />
      <RenderSizes code="G4" name="Campaign Kickoff" sizes={['IG']} Component={G4_Kickoff} />
      <RenderSizes code="G5" name="Award Win" sizes={['IG','LI']} Component={G5_Award} />
      <RenderSizes code="G6" name="Office / HQ Tour" sizes={['IG']} Component={G6_Office} />
      <RenderSizes code="G7" name="Festival Greeting" sizes={['IG']} Component={G7_Festival} />
      <RenderSizes code="G8" name="Year Wrapped" sizes={['IG','LI']} Component={G8_YearWrap} />
    </CategoryPage>
  );
}

function CategoryH() {
  return (
    <CategoryPage id="H" title="Memes & Viral"
      subtitle="Scroll-stoppers. Relatable, punchy, on-brand. Coral accent keeps them unmistakably Sorted.">
      <RenderSizes code="H1" name="Us vs Them Split" sizes={['IG','TW']} Component={H1_VsSplit} />
      <RenderSizes code="H2" name="Drake Format" sizes={['IG']} Component={H2_Drake} />
      <RenderSizes code="H3" name="Founder Pain" sizes={['IG']} Component={H3_FounderPain} />
      <RenderSizes code="H4" name="Expectation vs Reality" sizes={['IG','TW']} Component={H4_ExpVsReal} />
      <RenderSizes code="H5" name="IYKYK" sizes={['IG','TW']} Component={H5_IYKYK} />
      <RenderSizes code="H6" name="Nobody / Me" sizes={['IG']} Component={H6_NobodyMeme} />
      <RenderSizes code="H7" name="Vibe Check" sizes={['IG']} Component={H7_VibeCheck} />
      <RenderSizes code="H8" name="Not An Agency" sizes={['IG','LI']} Component={H8_NotAgency} />
    </CategoryPage>
  );
}

function CategoryI() {
  return (
    <CategoryPage id="I" title="Certificates & Badges"
      subtitle="Shareable client badges — ROAS club, email revenue club, partner certs, milestones, awards.">
      <RenderSizes code="I1" name="Certificate of Achievement" sizes={['IG','LI']} Component={I1_CertSuccess} />
      <RenderSizes code="I2" name="ROAS Club Badge" sizes={['IG']} Component={I2_RoasBadge} />
      <RenderSizes code="I3" name="Email Revenue Badge" sizes={['IG']} Component={I3_EmailBadge} />
      <RenderSizes code="I4" name="Partner Certificate" sizes={['IG','LI']} Component={I4_PartnerCert} />
      <RenderSizes code="I5" name="Milestone Ring" sizes={['IG']} Component={I5_Milestone} />
      <RenderSizes code="I6" name="Sorted Award" sizes={['IG','LI']} Component={I6_YearAward} />
    </CategoryPage>
  );
}

function CategoryJ() {
  return (
    <CategoryPage id="J" title="Slogans & Brand"
      subtitle="Pure brand voice. Type-forward, no filler. Drop these in when you just need to sound like Sorted.">
      <RenderSizes code="J1" name="Hero Slogan" sizes={['IG','TW','LI']} Component={J1_HeroSlogan} />
      <RenderSizes code="J2" name="Manifesto" sizes={['IG','LI']} Component={J2_Manifesto} />
      <RenderSizes code="J3" name="Values Grid" sizes={['IG','LI']} Component={J3_ValuesGrid} />
      <RenderSizes code="J4" name="Not An Agency" sizes={['IG','LI']} Component={J4_AntiAgency} />
      <RenderSizes code="J5" name="Revenue Leak" sizes={['IG','LI']} Component={J5_RevenueLeak} />
      <RenderSizes code="J6" name="Compound Growth" sizes={['IG','LI']} Component={J6_Compound} />
    </CategoryPage>
  );
}

function CategoryK() {
  return (
    <CategoryPage id="K" title="LinkedIn Specific"
      subtitle="Formats that only make sense on LinkedIn — 4:5 doc covers, poll recaps, hook posts, thought pieces.">
      <RenderSizes code="K1" name="Hook Post" sizes={['LI','LIDOC']} Component={K1_LIHeader} />
      <RenderSizes code="K2" name="Document Cover" sizes={['LIDOC']} Component={K2_LIDocCover} />
      <RenderSizes code="K3" name="Announcement" sizes={['LI','LIDOC']} Component={K3_LIAnnouncement} />
      <RenderSizes code="K4" name="Poll Recap" sizes={['LI','LIDOC']} Component={K4_LIPoll} />
      <RenderSizes code="K5" name="Thought Piece" sizes={['LI','LIDOC']} Component={K5_LIThought} />
      <RenderSizes code="K6" name="Team Announcement" sizes={['LI','LIDOC']} Component={K6_LITeamAnnounce} />
    </CategoryPage>
  );
}

function CategoryL() {
  return (
    <CategoryPage id="L" title="IG Stories & Reels"
      subtitle="9:16 vertical only. Big type, safe zones, swipe-up CTAs. Reel covers included.">
      <RenderSizes code="L1" name="Story Stat" sizes={['STORY']} Component={L1_StoryStat} />
      <RenderSizes code="L2" name="Story Tip" sizes={['STORY']} Component={L2_StoryTip} />
      <RenderSizes code="L3" name="This or That Poll" sizes={['STORY']} Component={L3_StoryThisOrThat} />
      <RenderSizes code="L4" name="Question Box" sizes={['STORY']} Component={L4_QuestionBox} />
      <RenderSizes code="L5" name="Reel Cover" sizes={['STORY']} Component={L5_ReelCover} />
      <RenderSizes code="L6" name="Audit CTA Story" sizes={['STORY']} Component={L6_AuditCTA} />
    </CategoryPage>
  );
}

Object.assign(window, { SIZES, RenderSizes, CategoryA, CategoryB, CategoryC, CategoryD, CategoryE, CategoryF, CategoryG, CategoryH, CategoryI, CategoryJ, CategoryK, CategoryL });
