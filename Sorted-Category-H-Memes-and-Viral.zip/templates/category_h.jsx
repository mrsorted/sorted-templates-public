// Category H — Memes & Viral (8)
function H1_VsSplit({w,h}){return(<>
<GridBg/><div style={{position:'absolute',left:'50%',top:40,bottom:40,width:2,background:C.coral,transform:'translateX(-50%)'}}/>
<TopLeftLogo top={30} left={40} height={20}/><BottomRightMark bottom={24} right={40} size={32}/>
<div style={{position:'absolute',inset:'60px 40px',display:'grid',gridTemplateColumns:'1fr 1fr'}}>
<div style={{padding:'30px 36px'}}>
<Eyebrow color={C.muted}>Other agencies:</Eyebrow>
<Display size={150} color={C.muted} lh={0.85} style={{marginTop:14}}>2.1×</Display>
<Body size={14} color={C.muted} style={{marginTop:6}}>ROAS · 6 months in</Body>
<Body size={13} color={C.muted} style={{marginTop:18,fontStyle:'italic'}}>"We need more creative…"</Body>
</div>
<div style={{padding:'30px 36px'}}>
<Eyebrow color={C.coral}>Sorted:</Eyebrow>
<Display size={150} color={C.coral} lh={0.85} style={{marginTop:14}}>4.8×</Display>
<Body size={14} color={C.white} style={{marginTop:6}}>ROAS · 6 months in</Body>
<Body size={13} color={C.white} weight={700} style={{marginTop:18}}>"12 creatives shipped this week."</Body>
</div></div></>);}

function H2_Drake({w,h}){return(<>
<GridBg/><TopLeftLogo top={30} left={40} height={20}/>
<div style={{position:'absolute',inset:'60px 40px',display:'grid',gridTemplateRows:'1fr 1fr',gap:14}}>
<div style={{display:'grid',gridTemplateColumns:'1fr 2fr',gap:14,background:C.navyLight,border:`1px solid ${C.border}`,borderRadius:10,overflow:'hidden'}}>
<div style={{background:'rgba(255,255,255,0.03)',display:'flex',alignItems:'center',justifyContent:'center'}}>
<Display size={80} color={C.muted} style={{opacity:0.6}}>✋</Display></div>
<div style={{padding:'24px 30px',display:'flex',alignItems:'center'}}>
<Display size={44} color={C.muted} lh={0.95}>Spending more on ads.</Display></div></div>
<div style={{display:'grid',gridTemplateColumns:'1fr 2fr',gap:14,background:C.navyLight,border:`1px solid ${C.coral}`,borderRadius:10,overflow:'hidden'}}>
<div style={{background:'rgba(232,38,75,0.1)',display:'flex',alignItems:'center',justifyContent:'center'}}>
<Display size={80} color={C.coral}>👉</Display></div>
<div style={{padding:'24px 30px',display:'flex',alignItems:'center'}}>
<Display size={44} color={C.coral} lh={0.95}>Fixing Klaviyo first.</Display></div></div>
</div>
<BottomRightMark bottom={16} right={40} size={30}/>
</>);}

function H3_FounderPain({w,h}){return(<>
<GridBg/><TopLeftLogo top={30} left={40} height={20}/>
<div style={{position:'absolute',top:80,left:50,right:50}}>
<Display size={54} color={C.white} lh={0.95}>D2C founder checking Meta ROAS at 11 PM:</Display></div>
<div style={{position:'absolute',left:50,right:50,top:240,bottom:60}}>
<PhotoPlaceholder h="100%" label="Drop reaction image / meme"/></div>
<BottomRightMark bottom={16} right={40} size={28}/>
</>);}

function H4_ExpVsReal({w,h}){return(<>
<GridBg/><TopLeftLogo top={30} left={40} height={20}/>
<div style={{position:'absolute',top:50,left:50,right:50}}>
<Display size={42} color={C.white}>Expectation vs Reality.</Display></div>
<div style={{position:'absolute',inset:'130px 40px 140px',display:'grid',gridTemplateColumns:'1fr 1fr',gap:20}}>
<div style={{background:C.navyLight,border:`1px solid ${C.border}`,borderRadius:10,padding:20}}>
<Eyebrow color={C.muted}>Expectation</Eyebrow>
<svg viewBox="0 0 300 200" style={{width:'100%',marginTop:10}}><path d="M10 180 Q 80 140, 150 90 T 290 20" stroke={C.muted} strokeWidth="3" fill="none"/></svg>
</div>
<div style={{background:C.navyLight,border:`1px solid ${C.coral}`,borderRadius:10,padding:20}}>
<Eyebrow color={C.coral}>Reality</Eyebrow>
<svg viewBox="0 0 300 200" style={{width:'100%',marginTop:10}}><path d="M10 180 L40 150 L70 170 L100 130 L130 160 L160 90 L190 120 L220 70 L250 100 L290 20" stroke={C.coral} strokeWidth="3" fill="none"/></svg>
</div></div>
<div style={{position:'absolute',bottom:40,left:50,right:50,textAlign:'center'}}>
<Body size={14} color={C.bodySoft}>Reality looks like the right. We make it go up anyway.</Body></div>
</>);}

function H5_IYKYK({w,h}){return(<>
<GridBg/><TopLeftLogo top={30} left={40} height={20}/>
<div style={{position:'absolute',inset:0,display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',padding:'0 60px',textAlign:'center'}}>
<Eyebrow color={C.muted} size={13} ls="0.32em">If you know, you know:</Eyebrow>
<Display size={100} color={C.white} lh={0.9} style={{marginTop:20}}>"The data team will circle back Monday."</Display>
</div>
<BottomRightMark bottom={30} right={40}/></>);}

function H6_NobodyMeme({w,h}){return(<>
<GridBg/><TopLeftLogo top={30} left={40} height={20}/>
<div style={{position:'absolute',top:70,left:50,right:50}}>
<Eyebrow color={C.muted}>Nobody:</Eyebrow>
<Display size={52} color={C.coral} lh={0.95} style={{marginTop:20}}>Sorted clients after fixing their Klaviyo:</Display></div>
<div style={{position:'absolute',left:50,right:50,top:260,bottom:60}}>
<PhotoPlaceholder h="100%" label="Drop reaction image"/></div>
<BottomRightMark bottom={16} right={40} size={28}/>
</>);}

function H7_VibeCheck({w,h}){const items=['Klaviyo over 35% ✓','Daily attribution ✓','UGC on deck ✓','Retainer-free ✓'];return(<>
<GridBg/><TopLeftLogo top={30} left={40} height={20}/>
<div style={{position:'absolute',top:100,left:60,right:60,textAlign:'center'}}>
<Display size={84} color={C.coral} lh={0.9}>Sorted Vibe Check ✓</Display></div>
<div style={{position:'absolute',left:80,right:80,top:300,display:'flex',flexDirection:'column',gap:16}}>
{items.map((t,i)=>(<div key={i} style={{display:'flex',gap:14,alignItems:'center',padding:'16px 22px',background:C.navyLight,border:`1px solid ${C.coral}`,borderRadius:8}}>
<div style={{width:26,height:26,borderRadius:6,background:C.coral,color:'#fff',display:'flex',alignItems:'center',justifyContent:'center',fontSize:14}}>✓</div>
<Body size={18} color={C.white}>{t}</Body></div>))}</div>
<div style={{position:'absolute',bottom:40,left:0,right:0,textAlign:'center'}}><Body size={13} color={C.muted} weight={700} style={{letterSpacing:'0.3em',textTransform:'uppercase'}}>We're built different.</Body></div>
</>);}

function H8_NotAgency({w,h}){return(<>
<GridBg/><TopLeftLogo top={30} left={40} height={20}/>
<div style={{position:'absolute',inset:0,display:'flex',flexDirection:'column',justifyContent:'center',padding:'0 60px'}}>
<Display size={90} color={C.muted} lh={0.95} style={{textDecoration:'line-through',textDecorationColor:C.coral}}>We're not an agency.</Display>
<Display size={90} color={C.coral} lh={0.95} style={{marginTop:18}}>We're your growth system.</Display>
<Body size={18} color={C.bodySoft} style={{marginTop:24,fontStyle:'italic'}}>Big difference.</Body>
</div>
<BottomRightMark bottom={30} right={40}/></>);}

Object.assign(window, {H1_VsSplit, H2_Drake, H3_FounderPain, H4_ExpVsReal, H5_IYKYK, H6_NobodyMeme, H7_VibeCheck, H8_NotAgency});
