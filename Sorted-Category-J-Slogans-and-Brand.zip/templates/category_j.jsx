// Category J — Slogans & Brand (6)
function J1_HeroSlogan({w,h}){return(<>
<GridBg/><TopLeftLogo top={40} left={40} height={22}/>
<BottomRightMark bottom={40} right={40} size={48}/>
<div style={{position:'absolute',inset:0,display:'flex',alignItems:'center',padding:'0 60px'}}>
<Display size={w===h?160:120} color={C.white} lh={0.88}>We build growth machines<span style={{color:C.coral}}>.</span></Display>
</div></>);}

function J2_Manifesto({w,h}){return(<>
<GridBg/><TopLeftLogo top={40} left={40} height={22}/>
<div style={{position:'absolute',inset:0,display:'flex',flexDirection:'column',justifyContent:'center',padding:'0 60px'}}>
<Display size={80} color={C.muted} lh={0.95}>Most agencies give you reports.</Display>
<Display size={100} color={C.coral} lh={0.95} style={{marginTop:20}}>We give you results.</Display>
</div>
<div style={{position:'absolute',bottom:40,left:0,right:0,display:'flex',justifyContent:'center'}}><Logo height={24}/></div>
</>);}

function J3_ValuesGrid({w,h}){const vals=[['Direct','No soft-pedalling.'],['Specific','Numbers over narrative.'],['Honest','If it\'s broken, we say so.'],['Bold','Play offence, not defence.']];return(<>
<GridBg/><TopLeftLogo top={40} left={40} height={22}/>
<div style={{position:'absolute',top:60,right:60}}><Eyebrow>Our Values</Eyebrow></div>
<div style={{position:'absolute',inset:'130px 50px 50px',display:'grid',gridTemplateColumns:'1fr 1fr',gridTemplateRows:'1fr 1fr',gap:16}}>
{vals.map(([t,s],i)=>(<div key={i} style={{background:C.navyLight,border:`1px solid ${C.border}`,borderTop:`3px solid ${C.coral}`,borderRadius:10,padding:30,display:'flex',flexDirection:'column',justifyContent:'space-between'}}>
<div style={{fontFamily:F.display,fontSize:80,color:C.white,lineHeight:0.9}}>{t}</div>
<Body size={14} color={C.muted}>{s}</Body></div>))}
</div></>);}

function J4_AntiAgency({w,h}){return(<>
<GridBg/><TopLeftLogo top={40} left={40} height={22}/>
<div style={{position:'absolute',inset:0,display:'flex',flexDirection:'column',justifyContent:'center',padding:'0 60px'}}>
<Display size={90} color={C.muted} lh={0.95} style={{textDecoration:'line-through',textDecorationColor:C.coral,textDecorationThickness:3}}>We're not an agency.</Display>
<Display size={90} color={C.coral} lh={0.95} style={{marginTop:16}}>We're your growth system.</Display>
<Body size={18} color={C.bodySoft} style={{marginTop:24,fontStyle:'italic'}}>Big difference.</Body>
</div>
<BottomRightMark bottom={40} right={40}/>
</>);}

function J5_RevenueLeak({w,h}){return(<>
<GridBg/><CoralGlow size={600} top="-20%" right="-20%" op={0.3}/>
<TopLeftLogo top={40} left={40} height={22}/>
<div style={{position:'absolute',inset:0,display:'flex',flexDirection:'column',justifyContent:'center',padding:'0 60px'}}>
<svg width="72" height="72" viewBox="0 0 48 48" fill="none"><path d="M24 4 C 24 4, 10 22, 10 32 a 14 14 0 0 0 28 0 C 38 22, 24 4, 24 4z" stroke={C.coral} strokeWidth="3" fill="none"/></svg>
<Display size={110} color={C.coral} lh={0.9} style={{marginTop:14}}>Your revenue is leaking.</Display>
<Body size={18} color={C.white} style={{marginTop:14,maxWidth:700}}>We'll show you exactly where. Free.</Body>
<div style={{marginTop:30}}><CtaButton size="lg">Book a Free Audit</CtaButton></div>
</div></>);}

function J6_Compound({w,h}){return(<>
<GridBg/><TopLeftLogo top={40} left={40} height={22}/>
<div style={{position:'absolute',inset:0,display:'flex',flexDirection:'column',justifyContent:'center',padding:'0 60px'}}>
<Display size={90} color={C.muted} lh={0.95}>Campaigns expire.</Display>
<Display size={100} color={C.white} lh={0.95} style={{marginTop:14}}>Growth systems <span style={{color:C.coral,borderBottom:`4px solid ${C.coral}`}}>compound</span>.</Display>
<Body size={16} color={C.bodySoft} style={{marginTop:24}}>We build the latter.</Body>
</div>
<BottomRightMark bottom={40} right={40}/>
</>);}

Object.assign(window, {J1_HeroSlogan, J2_Manifesto, J3_ValuesGrid, J4_AntiAgency, J5_RevenueLeak, J6_Compound});
